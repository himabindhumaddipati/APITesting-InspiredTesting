# Generic BDD Cucumber API Test Framework

A reusable, extensible BDD API testing framework built with:
**Cucumber 7 + REST Assured 5 + JUnit 4 + PicoContainer (DI)**

The ReqRes User API (reqres.in) is the first test suite built on top of this framework.

---

## Project Structure

```
bdd-cucumber-api-framework/
├── pom.xml
└── src/
    └── test/
        ├── java/
        │   ├── constants/
        │   │   └── ApiConstants.java              ← Endpoint paths & HTTP status codes
        │   ├── context/
        │   │   └── ScenarioContext.java            ← Scenario-scoped shared state (PicoContainer DI)
        │   ├── utils/
        │   │   ├── ConfigLoader.java               ← Reads config/config.properties
        │   │   ├── RequestBuilder.java             ← Builds REST Assured RequestSpecification
        │   │   └── ResponseValidator.java          ← All reusable assertion methods
        │   ├── stepdefinitions/
        │   │   ├── Hooks.java                      ← @Before / @After lifecycle
        │   │   └── CommonStepDefinitions.java      ← All Given/When/Then steps (generic)
        │   └── runner/
        │       └── TestRunner.java                 ← @RunWith(Cucumber.class) entry point
        └── resources/
            ├── config/
            │   └── config.properties               ← Base URL, API key, content type
            ├── testdata/
            │   └── user2.json                      ← Reference test data for ReqRes
            └── features/
                └── ReqResUserAPI.feature           ← 4 BDD test scenarios
```

---

## Framework Architecture

```
TestRunner.java
     │
     ├── Hooks.java            (@Before → builds auth request spec, @After → logs result)
     │
     ├── CommonStepDefinitions.java    (Given/When/Then — generic, reusable)
     │        │
     │        ├── RequestBuilder.java  (builds RestAssured specs from config)
     │        ├── ResponseValidator.java (all assertion logic)
     │        └── ScenarioContext.java  (shared state between steps)
     │
     └── ReqResUserAPI.feature  (test scenarios — only place with test-specific data)
```

---

## Test Cases

| TC ID | Tag | Operation | Endpoint | Expected |
|---|---|---|---|---|
| TC_001 | @GET @smoke | Retrieve user | GET /api/users/2 | 200 OK — all fields validated |
| TC_002 | @GET @ScriptValidation | Extract & log fields | GET /api/users/2 | First Name, Last Name, Support URL logged & asserted |
| TC_003 | @PUT @update | Update email | PUT /api/users/2 | 200 OK — email updated, updatedAt returned |
| TC_004 | @DELETE | Delete user | DELETE /api/users/2 | 204 No Content — empty body |

---

## Prerequisites

- Java 11+
- Maven 3.6+
- Eclipse IDE (recommended) or VS Code with Java Extension Pack

---

## How to Run

### Eclipse
1. Import project: `File → Import → Maven → Existing Maven Projects`
2. Right-click `TestRunner.java` → `Run As → JUnit Test`

### VS Code
Open terminal in project root, run:
```bash
mvn test
```

### By Tag (Terminal or Maven Build Goals)
```bash
# All tests
mvn test

# Single test case
mvn test -Dcucumber.filter.tags="@TC_001"
mvn test -Dcucumber.filter.tags="@TC_002"
mvn test -Dcucumber.filter.tags="@TC_003"
mvn test -Dcucumber.filter.tags="@TC_004"

# By operation type
mvn test -Dcucumber.filter.tags="@GET"
mvn test -Dcucumber.filter.tags="@PUT"
mvn test -Dcucumber.filter.tags="@DELETE"

# Smoke tests only
mvn test -Dcucumber.filter.tags="@smoke"
```

---

## Adding a New API Test Suite

1. Add endpoint constants to `ApiConstants.java`
2. Add test data under `src/test/resources/testdata/`
3. Create a new `.feature` file under `src/test/resources/features/`
4. Reuse existing steps from `CommonStepDefinitions` — **no new Java code needed** for standard CRUD

---

## Reports

After `mvn test`, open the HTML report:
```
target/cucumber-reports/report.html
```
