package runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

/**
 * Cucumber Test Runner — entry point for the framework.
 *
 * ─── Run Commands ───────────────────────────────────────────────────────────
 *   All tests          :  mvn test
 *   Single tag         :  mvn test -Dcucumber.filter.tags="@GET"
 *   Multiple tags      :  mvn test -Dcucumber.filter.tags="@GET or @PUT"
 *   Exclude tag        :  mvn test -Dcucumber.filter.tags="not @wip"
 *   Smoke only         :  mvn test -Dcucumber.filter.tags="@smoke"
 * ────────────────────────────────────────────────────────────────────────────
 */
@RunWith(Cucumber.class)
@CucumberOptions(
        features   = "src/test/resources/features",
        glue       = {"stepdefinitions"},
        plugin     = {
                "pretty",
                "html:target/cucumber-reports/report.html",
                "json:target/cucumber-reports/cucumber.json"
        },
        monochrome = true,
        tags       = "not @wip"
)
public class TestRunner {
}
