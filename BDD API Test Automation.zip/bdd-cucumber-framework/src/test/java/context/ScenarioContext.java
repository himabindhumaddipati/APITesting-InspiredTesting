package context;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.HashMap;
import java.util.Map;

/**
 * Scenario-scoped shared state container.
 * One fresh instance is created per Cucumber scenario via PicoContainer DI.
 *
 * Holds:
 *   - the active RequestSpecification
 *   - the last API Response
 *   - a key-value store for any extracted/logged values between steps
 */
public class ScenarioContext {

    private RequestSpecification requestSpec;
    private Response             response;
    private final Map<String, String> extractedValues = new HashMap<>();

    // ── Request ───────────────────────────────────────────────────────────────
    public RequestSpecification getRequestSpec()               { return requestSpec; }
    public void setRequestSpec(RequestSpecification spec)      { this.requestSpec = spec; }

    // ── Response ──────────────────────────────────────────────────────────────
    public Response getResponse()                              { return response; }
    public void setResponse(Response response)                 { this.response = response; }

    // ── Extracted values store ────────────────────────────────────────────────
    public void store(String key, String value)                { extractedValues.put(key, value); }
    public String retrieve(String key)                         { return extractedValues.get(key); }
    public boolean has(String key)                             { return extractedValues.containsKey(key); }
}
