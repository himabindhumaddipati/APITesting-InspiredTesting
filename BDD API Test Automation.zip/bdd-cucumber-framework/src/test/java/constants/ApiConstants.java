package constants;

/**
 * Central store for all API endpoint paths and HTTP status codes.
 * Add new endpoints here as the framework expands to cover more APIs.
 */
public class ApiConstants {

    private ApiConstants() {}

    // ── Endpoints ─────────────────────────────────────────────────────────────
    public static final String USERS_ENDPOINT      = "/api/users";
    public static final String USER_BY_ID_ENDPOINT = "/api/users/2";

    // ── HTTP Status Codes ─────────────────────────────────────────────────────
    public static final int STATUS_200 = 200;
    public static final int STATUS_201 = 201;
    public static final int STATUS_204 = 204;
    public static final int STATUS_400 = 400;
    public static final int STATUS_401 = 401;
    public static final int STATUS_404 = 404;

    // ── Content Types ─────────────────────────────────────────────────────────
    public static final String APPLICATION_JSON = "application/json";
}
