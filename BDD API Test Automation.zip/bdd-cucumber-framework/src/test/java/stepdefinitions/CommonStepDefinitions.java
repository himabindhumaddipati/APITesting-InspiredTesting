package stepdefinitions;

import context.ScenarioContext;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import utils.RequestBuilder;
import utils.ResponseValidator;

import static org.junit.Assert.*;

/**
 * Generic reusable step definitions.
 * These steps are NOT tied to any specific API or domain.
 * Any feature file in this framework can reuse these steps directly.
 *
 * Supported HTTP methods : GET, POST, PUT, PATCH, DELETE
 * Supported assertions   : status, content-type, JSON fields, headers,
 *                          empty body, response time, extract & log fields
 */
public class CommonStepDefinitions {

    private final ScenarioContext context;

    public CommonStepDefinitions(ScenarioContext context) {
        this.context = context;
    }

    // ── Setup ─────────────────────────────────────────────────────────────────

    @Given("I use authenticated request headers")
    public void useAuthenticatedHeaders() {
        context.setRequestSpec(RequestBuilder.buildAuthenticatedRequest());
    }

    @Given("I use unauthenticated request headers")
    public void useUnauthenticatedHeaders() {
        context.setRequestSpec(RequestBuilder.buildUnauthenticatedRequest());
    }

    @Given("the API is available at base URL {string}")
    public void setCustomBaseUrl(String baseUrl) {
        context.setRequestSpec(RequestBuilder.buildRequestForUrl(baseUrl));
    }

    // ── HTTP Methods ──────────────────────────────────────────────────────────

    @When("I send a GET request to {string}")
    public void sendGetRequest(String endpoint) {
        Response response = context.getRequestSpec()
                .when()
                .get(endpoint)
                .then()
                .extract()
                .response();
        context.setResponse(response);
    }

    @When("I send a POST request to {string} with body:")
    public void sendPostRequest(String endpoint, String body) {
        Response response = context.getRequestSpec()
                .body(body)
                .when()
                .post(endpoint)
                .then()
                .extract()
                .response();
        context.setResponse(response);
    }

    @When("I send a PUT request to {string} with body:")
    public void sendPutRequest(String endpoint, String body) {
        Response response = context.getRequestSpec()
                .body(body)
                .when()
                .put(endpoint)
                .then()
                .extract()
                .response();
        context.setResponse(response);
    }

    @When("I send a PATCH request to {string} with body:")
    public void sendPatchRequest(String endpoint, String body) {
        Response response = context.getRequestSpec()
                .body(body)
                .when()
                .patch(endpoint)
                .then()
                .extract()
                .response();
        context.setResponse(response);
    }

    @When("I send a DELETE request to {string}")
    public void sendDeleteRequest(String endpoint) {
        Response response = context.getRequestSpec()
                .when()
                .delete(endpoint)
                .then()
                .extract()
                .response();
        context.setResponse(response);
    }

    // ── Status & Headers ──────────────────────────────────────────────────────

    @Then("the response status code should be {int}")
    public void verifyStatusCode(int expected) {
        ResponseValidator.assertStatusCode(context.getResponse(), expected);
    }

    @And("the response content type should contain {string}")
    public void verifyContentType(String expected) {
        ResponseValidator.assertContentType(context.getResponse(), expected);
    }

    @And("the response header {string} should contain {string}")
    public void verifyHeader(String headerName, String expected) {
        ResponseValidator.assertHeaderContains(context.getResponse(), headerName, expected);
    }

    // ── JSON Field Assertions ─────────────────────────────────────────────────

    @And("the response field {string} should be {string}")
    public void verifyField(String jsonPath, String expected) {
        ResponseValidator.assertFieldEquals(context.getResponse(), jsonPath, expected);
    }

    @And("the response field {string} should not be empty")
    public void verifyFieldNotEmpty(String jsonPath) {
        ResponseValidator.assertFieldNotEmpty(context.getResponse(), jsonPath);
    }

    @And("the response body should be empty")
    public void verifyEmptyBody() {
        ResponseValidator.assertBodyIsEmpty(context.getResponse());
    }

    // ── Extract, Log and Store ────────────────────────────────────────────────

    @And("I extract and log {string} as {string}")
    public void extractAndLog(String jsonPath, String label) {
        String value = ResponseValidator.extractField(context.getResponse(), jsonPath);
        System.out.println("[LOG] " + label + " : " + value);
        context.store(label, value);
    }

    @And("the stored value {string} should equal {string}")
    public void verifyStoredValue(String label, String expected) {
        String actual = context.retrieve(label);
        assertNotNull("No stored value found for '" + label + "'", actual);
        assertEquals("Stored '" + label + "' mismatch", expected, actual);
    }

    @And("the stored value {string} should start with {string}")
    public void verifyStoredStartsWith(String label, String prefix) {
        String actual = context.retrieve(label);
        assertNotNull("No stored value found for '" + label + "'", actual);
        assertTrue(
            "Stored '" + label + "' = '" + actual + "' does not start with '" + prefix + "'",
            actual.startsWith(prefix)
        );
    }

    // ── Performance ───────────────────────────────────────────────────────────

    @And("the response time should be less than {int} milliseconds")
    public void verifyResponseTime(int maxMs) {
        ResponseValidator.assertResponseTimeBelow(context.getResponse(), maxMs);
    }
}
