package stepdefinitions;

import context.ScenarioContext;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.restassured.RestAssured;
import utils.ConfigLoader;
import utils.RequestBuilder;

/**
 * Cucumber lifecycle hooks.
 * Runs before and after every scenario.
 */
public class Hooks {

    private final ScenarioContext context;

    public Hooks(ScenarioContext context) {
        this.context = context;
    }

    @Before
    public void beforeScenario(Scenario scenario) {
        System.out.println("\n========================================");
        System.out.println("SCENARIO : " + scenario.getName());
        System.out.println("TAGS     : " + scenario.getSourceTagNames());
        System.out.println("========================================");

        RestAssured.baseURI = ConfigLoader.getBaseUrl();
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();

        // Build default authenticated request spec for every scenario
        context.setRequestSpec(RequestBuilder.buildAuthenticatedRequest());
    }

    @After
    public void afterScenario(Scenario scenario) {
        System.out.println("\n[RESULT] " + scenario.getName()
                + " --> " + (scenario.isFailed() ? "FAILED" : "PASSED"));
        System.out.println("========================================\n");
    }
}
