package utils;

import io.restassured.response.Response;

import static org.junit.Assert.*;

/**
 * Generic reusable response validation utility.
 * All assertion logic lives here — step definitions stay clean and readable.
 */
public class ResponseValidator {

    private ResponseValidator() {}

    public static void assertStatusCode(Response response, int expected) {
        int actual = response.getStatusCode();
        assertEquals(
            "Expected HTTP " + expected + " but got " + actual,
            expected, actual
        );
    }

    public static void assertContentType(Response response, String expected) {
        String actual = response.getContentType();
        assertTrue(
            "Content-Type '" + actual + "' does not contain '" + expected + "'",
            actual.contains(expected)
        );
    }

    public static void assertFieldEquals(Response response, String jsonPath, String expected) {
        Object actual = response.jsonPath().get(jsonPath);
        assertNotNull("JSON field '" + jsonPath + "' is null", actual);
        assertEquals("Mismatch at '" + jsonPath + "'", expected, actual.toString());
    }

    public static void assertFieldNotEmpty(Response response, String jsonPath) {
        Object value = response.jsonPath().get(jsonPath);
        assertNotNull("JSON field '" + jsonPath + "' is null", value);
        assertFalse("JSON field '" + jsonPath + "' is empty", value.toString().isEmpty());
    }

    public static void assertBodyIsEmpty(Response response) {
        String body = response.getBody().asString();
        assertTrue(
            "Expected empty body but got: " + body,
            body == null || body.trim().isEmpty() || body.trim().equals("{}")
        );
    }

    public static void assertHeaderContains(Response response, String headerName, String expected) {
        String actual = response.getHeader(headerName);
        assertNotNull("Header '" + headerName + "' is missing", actual);
        assertTrue(
            "Header '" + headerName + "' value '" + actual + "' does not contain '" + expected + "'",
            actual.contains(expected)
        );
    }

    public static void assertResponseTimeBelow(Response response, long maxMs) {
        long actual = response.getTime();
        assertTrue(
            "Response time " + actual + "ms exceeds limit of " + maxMs + "ms",
            actual < maxMs
        );
    }

    public static String extractField(Response response, String jsonPath) {
        Object value = response.jsonPath().get(jsonPath);
        assertNotNull("Cannot extract '" + jsonPath + "' — field is null", value);
        return value.toString();
    }
}
