package utils;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

/**
 * Generic reusable request builder.
 * Builds REST Assured RequestSpecification objects from config.
 * Callers add body / path params before calling .get() / .post() etc.
 */
public class RequestBuilder {

    private RequestBuilder() {}

    /** Standard authenticated request — used by most scenarios. */
    public static RequestSpecification buildAuthenticatedRequest() {
        return RestAssured
                .given()
                .baseUri(ConfigLoader.getBaseUrl())
                .header(ConfigLoader.getApiKeyHeader(), ConfigLoader.getApiKeyValue())
                .header("Content-Type", ConfigLoader.getContentType())
                .header("Accept", ConfigLoader.getContentType());
    }

    /** No auth headers — use for negative / unauthorised scenarios. */
    public static RequestSpecification buildUnauthenticatedRequest() {
        return RestAssured
                .given()
                .baseUri(ConfigLoader.getBaseUrl())
                .header("Content-Type", ConfigLoader.getContentType())
                .header("Accept", ConfigLoader.getContentType());
    }

    /** Custom base URL — use when switching environments at runtime. */
    public static RequestSpecification buildRequestForUrl(String baseUrl) {
        return RestAssured
                .given()
                .baseUri(baseUrl)
                .header(ConfigLoader.getApiKeyHeader(), ConfigLoader.getApiKeyValue())
                .header("Content-Type", ConfigLoader.getContentType())
                .header("Accept", ConfigLoader.getContentType());
    }
}
