@ReqRes @Users
Feature: ReqRes User API - CRUD Operations
  As a QA Engineer
  I want to validate all CRUD operations on the ReqRes User API
  So that I can confirm the endpoint behaves correctly for user ID 2

  Background:
    Given I use authenticated request headers

  # ───────────────────────────────────────────────────────────────────────
  # TC_001 : Retrieve user data (GET)
  # Postman : GET /api/users/2 --> 200 OK
  # Validates: status code, content type, all data fields
  # ───────────────────────────────────────────────────────────────────────
  @GET @smoke @TC_001
  Scenario: TC_001 - Retrieve user data for user ID 2
    When I send a GET request to "/api/users/2"
    Then the response status code should be 200
    And  the response content type should contain "application/json"
    And  the response field "data.id" should be "2"
    And  the response field "data.email" should be "janet.weaver@reqres.in"
    And  the response field "data.first_name" should be "Janet"
    And  the response field "data.last_name" should be "Weaver"
    And  the response field "data.avatar" should not be empty
    And  the response field "support.url" should not be empty
    And  the response field "support.text" should not be empty

  # ───────────────────────────────────────────────────────────────────────
  # TC_002 : Script Validation - Extract and log response fields
  # Postman : Scripts tab --> console.log first name, last name, support URL
  # Validates: extracted values match expected, URL starts with https://
  # ───────────────────────────────────────────────────────────────────────
  @GET @ScriptValidation @TC_002
  Scenario: TC_002 - Extract and log first name, last name and support URL
    When I send a GET request to "/api/users/2"
    Then the response status code should be 200
    And  I extract and log "data.first_name" as "First Name"
    And  I extract and log "data.last_name" as "Last Name"
    And  I extract and log "support.url" as "Support URL"
    And  the stored value "First Name" should equal "Janet"
    And  the stored value "Last Name" should equal "Weaver"
    And  the stored value "Support URL" should start with "https://"

  # ───────────────────────────────────────────────────────────────────────
  # TC_003 : Update user email (PUT)
  # Postman : PUT /api/users/2 body: { "email": "himabindhu@gmail.com" }
  # Validates: 200 OK, updated email returned, updatedAt timestamp present
  # ───────────────────────────────────────────────────────────────────────
  @PUT @update @TC_003
  Scenario: TC_003 - Update user email using PUT
    When I send a PUT request to "/api/users/2" with body:
      """
      {
        "email": "himabindhu@gmail.com"
      }
      """
    Then the response status code should be 200
    And  the response field "email" should be "himabindhu@gmail.com"
    And  the response field "updatedAt" should not be empty

  # ───────────────────────────────────────────────────────────────────────
  # TC_004 : Delete user (DELETE)
  # Postman : DELETE /api/users/2 --> 204 No Content
  # Validates: 204 status, response body is empty
  # ───────────────────────────────────────────────────────────────────────
  @DELETE @TC_004
  Scenario: TC_004 - Delete user ID 2
    When I send a DELETE request to "/api/users/2"
    Then the response status code should be 204
    And  the response body should be empty
