# =============================================================================
#  Feature: Purchase Desktop Computer
#  Application: https://demowebshop.tricentis.com
#  Credentials: himabindhumaddipati@gmail.com / hima@123
# =============================================================================

@purchase @smoke
Feature: Purchase a Desktop Computer from Tricentis Demo WebShop

  As a registered customer
  I want to purchase a "Build your own cheap computer" desktop
  So that I can complete a full end-to-end order using Cash on Delivery

  Background:
    Given the user is on the Tricentis Demo WebShop homepage

  @e2e @regression
  Scenario: Successfully purchase Build Your Own Cheap Computer with Cash on Delivery

    # Step 1 - Login
    When the user logs in with email "himabindhumaddipati@gmail.com" and password "hima@123"
    Then the user should be logged in successfully

    # Step 2 - Navigate
    When the user goes to "Computers" menu and selects "Desktops"
    Then the Desktops page should be displayed

    # Step 3 - Select Product
    When the user selects the product "Build your own cheap computer"
    Then the product detail page should be displayed

    # Step 4 - Add to Cart
    When the user adds the product to the cart
    Then the cart should contain the product

    # Step 5 - Accept T&Cs and Checkout
    When the user accepts the Terms and Conditions
    And the user clicks Checkout

    # Step 6 - Billing and Shipping
    When the user fills in billing details with the following:
      | firstName | Hima                          |
      | lastName  | Maddipati                     |
      | email     | himabindhumaddipati@gmail.com |
      | company   | Test Corp                     |
      | country   | South Africa                  |
      | state     | Other                         |
      | city      | Cape Town                     |
      | address   | 123 Test Street               |
      | zip       | 8001                          |
      | phone     | 0210000000                    |
    And the user continues past the shipping step

    # Step 7 - Payment Method
    When the user selects "Cash On Delivery" as the payment method
    And the user continues past the payment info step

    # Step 8 - Confirm Order
    When the user confirms the order

    # Step 9 - Capture Order Number
    Then the order should be placed successfully
    And the order number should be captured and logged
