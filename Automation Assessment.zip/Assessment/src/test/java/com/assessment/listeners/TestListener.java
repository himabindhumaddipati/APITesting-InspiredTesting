package com.assessment.listeners;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 * TestListener
 * TestNG event listener — logs all test lifecycle events.
 * Registered in testng.xml so it applies to the entire suite.
 */
public class TestListener implements ITestListener {

    private static final Logger log = LogManager.getLogger(TestListener.class);

    @Override
    public void onTestStart(ITestResult result) {
        log.info("▶  STARTED  : {}", result.getName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        log.info("✅  PASSED   : {}", result.getName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        log.error("❌  FAILED   : {} — {}", result.getName(),
                result.getThrowable().getMessage());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        log.warn("⚠️  SKIPPED  : {}", result.getName());
    }
}
