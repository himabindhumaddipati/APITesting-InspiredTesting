package com.assessment.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * ConfigReader
 * Loads all values from config.properties.
 * System properties (-D flags) override file values — useful for CI pipelines.
 */
public class ConfigReader {

    private static final Logger log = LogManager.getLogger(ConfigReader.class);
    private static final Properties props = new Properties();

    static {
        try (FileInputStream fis = new FileInputStream(
                "src/test/resources/config/config.properties")) {
            props.load(fis);
            log.info("Configuration loaded successfully.");
        } catch (IOException e) {
            log.error("Failed to load config.properties", e);
            throw new RuntimeException("Cannot load config.properties", e);
        }
    }

    private ConfigReader() { }

    public static String get(String key) {
        return System.getProperty(key, props.getProperty(key));
    }

    public static String  getBaseUrl()          { return get("base.url"); }
    public static String  getBrowser()          { return get("browser"); }
    public static boolean isHeadless()          { return Boolean.parseBoolean(get("headless")); }
    public static int     getImplicitWait()     { return Integer.parseInt(get("implicit.wait")); }
    public static int     getExplicitWait()     { return Integer.parseInt(get("explicit.wait")); }
    public static int     getPageLoadTimeout()  { return Integer.parseInt(get("page.load.timeout")); }
    public static String  getUsername()         { return get("app.username"); }
    public static String  getPassword()         { return get("app.password"); }
    public static boolean screenshotOnFail()    { return Boolean.parseBoolean(get("screenshot.on.failure")); }
    public static String  getReportPath()       { return get("report.path"); }
    public static String  getScreenshotPath()   { return get("screenshot.path"); }
}
