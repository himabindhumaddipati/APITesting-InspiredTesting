package com.assessment.stepdefs;

import com.assessment.pages.*;
import com.assessment.utils.DriverManager;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.*;
import org.junit.Assert;

import java.util.Map;

/**
 * PurchaseDesktopSteps
 * Step Definitions — maps every Gherkin step in PurchaseDesktop.feature to Java.
 */
public class PurchaseDesktopSteps {

    // ── Page Objects ──────────────────────────────────────────────────────────
    private LoginPage        loginPage;
    private HomePage         homePage;
    private ProductPage      productPage;
    private ShoppingCartPage cartPage;
    private CheckoutPage     checkoutPage;

    // ── State ─────────────────────────────────────────────────────────────────
    private String capturedOrderNumber;

    // ── Hooks ─────────────────────────────────────────────────────────────────

    @Before
    public void setUp(Scenario scenario) {
        System.out.println("\n========================================");
        System.out.println("  SCENARIO: " + scenario.getName());
        System.out.println("========================================");
        DriverManager.initDriver();
    }

    @After
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            try {
                byte[] screenshot = ((org.openqa.selenium.TakesScreenshot)
                        DriverManager.getDriver())
                        .getScreenshotAs(org.openqa.selenium.OutputType.BYTES);
                scenario.attach(screenshot, "image/png", "Failure Screenshot");
            } catch (Exception e) {
                System.err.println("Screenshot capture failed: " + e.getMessage());
            }
        }
        DriverManager.quitDriver();
        System.out.println("========================================\n");
    }

    // ── Background ────────────────────────────────────────────────────────────

    @Given("the user is on the Tricentis Demo WebShop homepage")
    public void theUserIsOnTheHomepage() {
        homePage = new HomePage();
        homePage.open();
        Assert.assertTrue("Homepage should load",
                homePage.getCurrentUrl().contains("demowebshop.tricentis.com"));
    }

    // ── Step 1: Login ─────────────────────────────────────────────────────────

    @When("the user logs in with email {string} and password {string}")
    public void theUserLogsIn(String email, String password) {
        loginPage = new LoginPage();
        loginPage.login(email, password);
    }

    @Then("the user should be logged in successfully")
    public void theUserShouldBeLoggedIn() {
        Assert.assertTrue("User should be logged in", loginPage.isLoggedIn());
        System.out.println("  ✅  Logged in as: " + loginPage.getLoggedInUser());
    }

    // ── Step 2: Navigation ────────────────────────────────────────────────────

    @When("the user goes to {string} menu and selects {string}")
    public void theUserNavigatesMenu(String menu, String subMenu) {
        homePage.navigateToDesktops();
    }

    @Then("the Desktops page should be displayed")
    public void theDesktopsPageShouldBeDisplayed() {
        Assert.assertTrue("URL should contain /desktops",
                homePage.getCurrentUrl().contains("/desktops"));
    }

    // ── Step 3: Select Product ────────────────────────────────────────────────

    @When("the user selects the product {string}")
    public void theUserSelectsProduct(String productName) {
        productPage = new ProductPage();
        productPage.selectProductByName(productName);
    }

    @Then("the product detail page should be displayed")
    public void theProductDetailPageShouldBeDisplayed() {
        Assert.assertTrue("Product detail page should load",
                productPage.isProductDetailLoaded());
        System.out.println("  ✅  Product: " + productPage.getProductTitle());
    }

    // ── Step 4: Add to Cart ───────────────────────────────────────────────────

    @When("the user adds the product to the cart")
    public void theUserAddsProductToCart() {
        productPage.addToCart();
    }

    @Then("the cart should contain the product")
    public void theCartShouldContainProduct() {
        cartPage = new ShoppingCartPage();
        cartPage.open();
        Assert.assertTrue("Cart should have at least one item",
                cartPage.getCartItemCount() > 0);
        System.out.println("  ✅  Cart items: " + cartPage.getCartItemCount());
    }

    // ── Step 5: T&Cs + Checkout ───────────────────────────────────────────────

    @When("the user accepts the Terms and Conditions")
    public void theUserAcceptsTerms() {
        if (cartPage == null) { cartPage = new ShoppingCartPage(); cartPage.open(); }
        cartPage.acceptTermsAndConditions();
    }

    @When("the user clicks Checkout")
    public void theUserClicksCheckout() {
        cartPage.clickCheckout();
        checkoutPage = new CheckoutPage();
    }

    // ── Step 6: Billing Details ───────────────────────────────────────────────

    @When("the user fills in billing details with the following:")
    public void theUserFillsBillingDetails(DataTable dataTable) {
        Map<String, String> data = dataTable.asMap(String.class, String.class);
        if (checkoutPage == null) checkoutPage = new CheckoutPage();
        checkoutPage.fillBillingDetails(
                data.get("firstName"), data.get("lastName"),
                data.get("email"),     data.get("company"),
                data.get("country"),   data.get("state"),
                data.get("city"),      data.get("address"),
                data.get("zip"),       data.get("phone")
        );
    }

    @When("the user continues past the shipping step")
    public void theUserContinuesPastShipping() {
        checkoutPage.continueShipping();
    }

    // ── Step 7: Payment ───────────────────────────────────────────────────────

    @When("the user selects {string} as the payment method")
    public void theUserSelectsPaymentMethod(String method) {
        checkoutPage.selectCashOnDelivery();
    }

    @When("the user continues past the payment info step")
    public void theUserContinuesPastPaymentInfo() {
        checkoutPage.continuePaymentInfo();
    }

    // ── Step 8: Confirm ───────────────────────────────────────────────────────

    @When("the user confirms the order")
    public void theUserConfirmsTheOrder() {
        checkoutPage.confirmOrder();
    }

    // ── Step 9: Assert + Capture Order # ─────────────────────────────────────

    @Then("the order should be placed successfully")
    public void theOrderShouldBePlacedSuccessfully() {
        Assert.assertTrue("Order confirmation page should be displayed",
                checkoutPage.isOrderConfirmed());
    }

    @Then("the order number should be captured and logged")
    public void theOrderNumberShouldBeCapturedAndLogged() {
        capturedOrderNumber = checkoutPage.getOrderNumber();
        Assert.assertFalse("Order number should not be empty",
                capturedOrderNumber.isEmpty());

        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║   ✅  ORDER PLACED SUCCESSFULLY       ║");
        System.out.println("║   📦  Order Number: " + capturedOrderNumber + "             ║");
        System.out.println("╚══════════════════════════════════════╝\n");
    }
}
