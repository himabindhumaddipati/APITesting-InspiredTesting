package com.assessment.runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

/**
 * TestRunner
 * ─────────────────────────────────────────────────────────────────────
 * Cucumber JUnit Runner — entry point for BDD test execution.
 *
 * HOW TO RUN:
 *   mvn test                                    → runs @smoke scenarios
 *   mvn test -Dcucumber.filter.tags="@e2e"      → runs @e2e only
 *   mvn test -Dcucumber.filter.tags="@regression" → regression suite
 *   mvn test -Dheadless=true                    → headless Chrome
 *
 * REPORTS GENERATED:
 *   test-output/ExtentReport.html               → Extent HTML report
 *   target/cucumber-reports/cucumber.html       → Cucumber HTML report
 *   target/cucumber-reports/cucumber.json       → JSON for CI/CD
 * ─────────────────────────────────────────────────────────────────────
 */
@RunWith(Cucumber.class)
@CucumberOptions(
        features  = "src/test/resources/features",
        glue      = "com.assessment.stepdefs",
        tags      = "@smoke",
        plugin    = {
                "pretty",
                "html:target/cucumber-reports/cucumber.html",
                "json:target/cucumber-reports/cucumber.json",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        monochrome = true
)
public class TestRunner {
    // Intentionally empty — JUnit + Cucumber handle execution
}
