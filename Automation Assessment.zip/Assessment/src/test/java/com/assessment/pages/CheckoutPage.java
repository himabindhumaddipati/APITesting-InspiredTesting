package com.assessment.pages;

import com.assessment.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * CheckoutPage
 * Page Object for the multi-step checkout flow:
 * Billing → Shipping → Payment Method → Payment Info → Confirm → Complete
 */
public class CheckoutPage extends BasePage {

    // ── Billing ───────────────────────────────────────────────────────────────

    @FindBy(id = "BillingNewAddress_FirstName")   private WebElement firstName;
    @FindBy(id = "BillingNewAddress_LastName")    private WebElement lastName;
    @FindBy(id = "BillingNewAddress_Email")       private WebElement email;
    @FindBy(id = "BillingNewAddress_Company")     private WebElement company;
    @FindBy(id = "BillingNewAddress_CountryId")   private WebElement country;
    @FindBy(id = "BillingNewAddress_StateProvinceId") private WebElement state;
    @FindBy(id = "BillingNewAddress_City")        private WebElement city;
    @FindBy(id = "BillingNewAddress_Address1")    private WebElement address1;
    @FindBy(id = "BillingNewAddress_ZipPostalCode") private WebElement zip;
    @FindBy(id = "BillingNewAddress_PhoneNumber") private WebElement phone;

    @FindBy(css = "input[onclick='Billing.save()']")
    private WebElement billingContinue;

    // ── Shipping ──────────────────────────────────────────────────────────────

    @FindBy(css = "input[onclick='Shipping.save()']")
    private WebElement shippingContinue;

    // ── Payment Method ────────────────────────────────────────────────────────

    @FindBy(css = "input[value='Payments.CashOnDelivery']")
    private WebElement cashOnDeliveryRadio;

    @FindBy(css = "input[onclick='PaymentMethod.save()']")
    private WebElement paymentMethodContinue;

    // ── Payment Info ──────────────────────────────────────────────────────────

    @FindBy(css = "input[onclick='PaymentInfo.save()']")
    private WebElement paymentInfoContinue;

    // ── Confirm ───────────────────────────────────────────────────────────────

    @FindBy(css = "input[value='Confirm']")
    private WebElement confirmButton;

    // ── Completion ────────────────────────────────────────────────────────────

    @FindBy(css = ".order-number strong")
    private WebElement orderNumberEl;

    // ── Constructor ───────────────────────────────────────────────────────────

    public CheckoutPage() {
        super();
    }

    // ── Step 1: Billing ───────────────────────────────────────────────────────

    public void fillBillingDetails(String fn, String ln, String em, String co,
                                   String cnt, String st, String ct, String addr,
                                   String zp, String ph) {
        log.info("Filling billing details");
        waitForVisible(By.id("BillingNewAddress_FirstName"));
        type(firstName, fn);
        type(lastName,  ln);
        type(email,     em);
        type(company,   co);
        selectByText(country, cnt);
        waitForVisible(By.id("BillingNewAddress_StateProvinceId"));
        try { selectByText(state, st); } catch (Exception ignored) { }
        type(city,    ct);
        type(address1, addr);
        type(zip,     zp);
        type(phone,   ph);
        click(billingContinue);
    }

    // ── Step 2: Shipping ──────────────────────────────────────────────────────

    public void continueShipping() {
        log.info("Continuing past shipping step");
        waitForClickable(By.cssSelector("input[onclick='Shipping.save()']"));
        click(shippingContinue);
    }

    // ── Step 3: Payment Method ────────────────────────────────────────────────

    public void selectCashOnDelivery() {
        log.info("Selecting Cash on Delivery");
        waitForClickable(By.cssSelector("input[value='Payments.CashOnDelivery']"));
        if (!cashOnDeliveryRadio.isSelected()) jsClick(cashOnDeliveryRadio);
        click(paymentMethodContinue);
    }

    // ── Step 4: Payment Info ──────────────────────────────────────────────────

    public void continuePaymentInfo() {
        log.info("Continuing past payment info step");
        waitForClickable(By.cssSelector("input[onclick='PaymentInfo.save()']"));
        click(paymentInfoContinue);
    }

    // ── Step 5: Confirm ───────────────────────────────────────────────────────

    public void confirmOrder() {
        log.info("Confirming order");
        waitForClickable(By.cssSelector("input[value='Confirm']"));
        click(confirmButton);
    }

    // ── Assertions ────────────────────────────────────────────────────────────

    public boolean isOrderConfirmed() {
        return isDisplayed(By.cssSelector(".order-completed"));
    }

    public String getOrderNumber() {
        waitForVisible(By.cssSelector(".order-number"));
        return orderNumberEl.getText().replaceAll("[^0-9]", "");
    }
}
