package com.assessment.pages;

import com.assessment.base.BasePage;
import com.assessment.config.ConfigReader;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * HomePage
 * Page Object for the Tricentis Demo WebShop home / navigation.
 */
public class HomePage extends BasePage {

    // ── Locators ──────────────────────────────────────────────────────────────

    @FindBy(css = "ul.top-menu > li > a[href='/computers']")
    private WebElement computersMenu;

    @FindBy(css = "ul.top-menu a[href='/desktops']")
    private WebElement desktopsLink;

    @FindBy(css = "ul.top-menu a[href='/notebooks']")
    private WebElement notebooksLink;

    @FindBy(css = "a[href='/logout']")
    private WebElement logoutLink;

    // ── Constructor ───────────────────────────────────────────────────────────

    public HomePage() {
        super();
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    public void open() {
        log.info("Opening: {}", ConfigReader.getBaseUrl());
        navigateTo(ConfigReader.getBaseUrl());
    }

    public void navigateToDesktops() {
        log.info("Navigating to Computers > Desktops");
        click(computersMenu);
        click(desktopsLink);
    }

    public void navigateToNotebooks() {
        log.info("Navigating to Computers > Notebooks");
        click(computersMenu);
        click(notebooksLink);
    }

    public void logout() {
        log.info("Logging out");
        click(logoutLink);
    }

    public boolean isHomePageLoaded() {
        return getCurrentUrl().contains("demowebshop.tricentis.com");
    }
}
