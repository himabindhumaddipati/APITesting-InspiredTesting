package com.assessment.pages;

import com.assessment.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * LoginPage
 * Page Object for the Tricentis Demo WebShop login page.
 * URL: https://demowebshop.tricentis.com/login
 */
public class LoginPage extends BasePage {

    // ── Locators ──────────────────────────────────────────────────────────────

    @FindBy(css = "a[href='/login']")
    private WebElement loginNavLink;

    @FindBy(id = "Email")
    private WebElement emailInput;

    @FindBy(id = "Password")
    private WebElement passwordInput;

    @FindBy(css = "input.login-button")
    private WebElement loginButton;

    @FindBy(css = "div.account")
    private WebElement accountIndicator;

    @FindBy(css = ".validation-summary-errors")
    private WebElement validationError;

    private static final By ACCOUNT_INDICATOR = By.cssSelector("div.account");

    // ── Constructor ───────────────────────────────────────────────────────────

    public LoginPage() {
        super();
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    public void clickLoginLink() {
        log.info("Clicking Login nav link");
        click(loginNavLink);
    }

    public void enterEmail(String email) {
        log.info("Entering email: {}", email);
        type(emailInput, email);
    }

    public void enterPassword(String password) {
        log.info("Entering password");
        type(passwordInput, password);
    }

    public void clickLoginButton() {
        log.info("Clicking Login button");
        click(loginButton);
    }

    /**
     * Full login flow — navigate, enter credentials, submit.
     */
    public void login(String email, String password) {
        clickLoginLink();
        enterEmail(email);
        enterPassword(password);
        clickLoginButton();
    }

    // ── Assertions ────────────────────────────────────────────────────────────

    public boolean isLoggedIn() {
        return isDisplayed(ACCOUNT_INDICATOR);
    }

    public String getValidationError() {
        return isDisplayed(By.cssSelector(".validation-summary-errors"))
                ? getText(validationError) : "";
    }

    public String getLoggedInUser() {
        return isLoggedIn() ? getText(accountIndicator) : "";
    }
}
