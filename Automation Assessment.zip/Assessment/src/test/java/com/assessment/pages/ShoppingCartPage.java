package com.assessment.pages;

import com.assessment.base.BasePage;
import com.assessment.config.ConfigReader;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * ShoppingCartPage
 * Page Object for the shopping cart and checkout initiation.
 */
public class ShoppingCartPage extends BasePage {

    // ── Locators ──────────────────────────────────────────────────────────────

    @FindBy(id = "termsofservice")
    private WebElement termsCheckbox;

    @FindBy(id = "checkout")
    private WebElement checkoutButton;

    @FindBy(css = ".cart-item-row")
    private java.util.List<org.openqa.selenium.WebElement> cartItems;

    // ── Constructor ───────────────────────────────────────────────────────────

    public ShoppingCartPage() {
        super();
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    public void open() {
        log.info("Navigating to cart");
        navigateTo(ConfigReader.getBaseUrl() + "/cart");
    }

    public void acceptTermsAndConditions() {
        log.info("Accepting Terms & Conditions");
        waitForClickable(org.openqa.selenium.By.id("termsofservice"));
        if (!termsCheckbox.isSelected()) {
            jsClick(termsCheckbox);
        }
    }

    public void clickCheckout() {
        log.info("Clicking Checkout");
        click(checkoutButton);
    }

    public int getCartItemCount() {
        return cartItems.size();
    }

    public boolean isCartPageDisplayed() {
        return getCurrentUrl().contains("/cart");
    }
}
