package com.assessment.pages;

import com.assessment.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * ProductPage
 * Page Object covering both the product listing and product detail pages.
 */
public class ProductPage extends BasePage {

    // ── Listing Locators ──────────────────────────────────────────────────────

    @FindBy(css = ".product-title a")
    private List<WebElement> productTitles;

    @FindBy(css = "h1.product-title")
    private WebElement productDetailTitle;

    // ── Detail Locators ───────────────────────────────────────────────────────

    @FindBy(css = "input[value='Add to cart']")
    private WebElement addToCartButton;

    @FindBy(css = ".bar-notification.success")
    private WebElement successNotification;

    // ── Constructor ───────────────────────────────────────────────────────────

    public ProductPage() {
        super();
    }

    // ── Listing Actions ───────────────────────────────────────────────────────

    /**
     * Clicks the first product whose title contains the given text (case-insensitive).
     */
    public void selectProductByName(String productName) {
        log.info("Selecting product: {}", productName);
        for (WebElement product : productTitles) {
            if (product.getText().toLowerCase().contains(productName.toLowerCase())) {
                scrollTo(product);
                click(product);
                return;
            }
        }
        throw new RuntimeException("Product not found: " + productName);
    }

    // ── Detail Actions ────────────────────────────────────────────────────────

    public String getProductTitle() {
        return getText(productDetailTitle);
    }

    public void addToCart() {
        log.info("Adding product to cart");
        scrollTo(addToCartButton);
        click(addToCartButton);
        // Allow notification bar to appear
        try { Thread.sleep(1500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    public boolean isAddToCartSuccessful() {
        return isDisplayed(By.cssSelector(".bar-notification.success"));
    }

    public boolean isProductDetailLoaded() {
        return isDisplayed(By.cssSelector("h1.product-title"));
    }
}
