package com.assessment.tests;

import com.assessment.base.BaseTest;
import com.assessment.config.ConfigReader;
import com.assessment.pages.LoginPage;
import com.assessment.utils.ExtentReportManager;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * LoginTest
 * Validates login functionality on Tricentis Demo WebShop.
 */
public class LoginTest extends BaseTest {

    @Test(
        groups      = {"smoke", "regression"},
        description = "Verify successful login with valid credentials"
    )
    public void validLoginTest() {
        ExtentReportManager.getTest().info("Attempting login with valid credentials");
        LoginPage loginPage = new LoginPage();
        loginPage.login(ConfigReader.getUsername(), ConfigReader.getPassword());

        ExtentReportManager.getTest().info("Verifying user is logged in");
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after valid credentials");

        log.info("Logged in as: {}", loginPage.getLoggedInUser());
        ExtentReportManager.getTest().info("Logged in as: " + loginPage.getLoggedInUser());
    }

    @Test(
        groups      = {"smoke", "regression"},
        description = "Verify error is shown for invalid credentials"
    )
    public void invalidLoginTest() {
        ExtentReportManager.getTest().info("Attempting login with invalid credentials");
        LoginPage loginPage = new LoginPage();
        loginPage.login("wrong@email.com", "WrongPassword123");

        String error = loginPage.getValidationError();
        ExtentReportManager.getTest().info("Validation error: " + error);

        Assert.assertFalse(error.isEmpty(),
                "Validation error should be displayed for invalid credentials");
        Assert.assertFalse(loginPage.isLoggedIn(),
                "User should NOT be logged in with invalid credentials");
    }

    @Test(
        groups      = {"regression"},
        description = "Verify login page is accessible from home"
    )
    public void loginPageNavigationTest() {
        ExtentReportManager.getTest().info("Navigating to login page");
        LoginPage loginPage = new LoginPage();
        loginPage.clickLoginLink();

        Assert.assertTrue(loginPage.getCurrentUrl().contains("/login"),
                "URL should contain '/login' after clicking Login link");
    }
}
