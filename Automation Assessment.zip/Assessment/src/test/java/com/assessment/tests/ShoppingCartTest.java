package com.assessment.tests;

import com.assessment.base.BaseTest;
import com.assessment.config.ConfigReader;
import com.assessment.pages.*;
import com.assessment.utils.ExtentReportManager;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * ShoppingCartTest
 * End-to-end test covering the full purchase flow on Tricentis Demo WebShop:
 *   Login → Computers > Desktops → Select Product → Add to Cart →
 *   Accept T&Cs → Checkout → Billing → Shipping → CoD → Confirm → Capture Order #
 */
public class ShoppingCartTest extends BaseTest {

    @Test(
        groups      = {"smoke", "regression"},
        description = "End-to-end: Purchase 'Build your own cheap computer' via Cash on Delivery"
    )
    public void purchaseDesktopWithCashOnDeliveryTest() {

        // ── Step 1: Login ─────────────────────────────────────────────────────
        ExtentReportManager.getTest().info("Step 1: Logging in");
        LoginPage loginPage = new LoginPage();
        loginPage.login(ConfigReader.getUsername(), ConfigReader.getPassword());
        Assert.assertTrue(loginPage.isLoggedIn(), "User must be logged in before purchasing");

        // ── Step 2: Navigate to Computers > Desktops ──────────────────────────
        ExtentReportManager.getTest().info("Step 2: Navigating to Computers > Desktops");
        HomePage homePage = new HomePage();
        homePage.navigateToDesktops();

        // ── Step 3: Select Product ────────────────────────────────────────────
        ExtentReportManager.getTest().info("Step 3: Selecting 'Build your own cheap computer'");
        ProductPage productPage = new ProductPage();
        productPage.selectProductByName("Build your own cheap computer");

        String productTitle = productPage.getProductTitle();
        log.info("Product selected: {}", productTitle);
        ExtentReportManager.getTest().info("Product: " + productTitle);

        // ── Step 4: Add to Cart ───────────────────────────────────────────────
        ExtentReportManager.getTest().info("Step 4: Adding product to cart");
        productPage.addToCart();

        // ── Step 5: Navigate to Cart, Accept T&Cs, Checkout ──────────────────
        ExtentReportManager.getTest().info("Step 5: Opening cart and accepting Terms & Conditions");
        ShoppingCartPage cartPage = new ShoppingCartPage();
        cartPage.open();
        Assert.assertTrue(cartPage.getCartItemCount() > 0, "Cart should contain at least one item");
        cartPage.acceptTermsAndConditions();

        ExtentReportManager.getTest().info("Proceeding to checkout");
        cartPage.clickCheckout();

        // ── Step 6 & 7: Billing + Shipping ────────────────────────────────────
        ExtentReportManager.getTest().info("Step 6: Filling billing & shipping details");
        CheckoutPage checkoutPage = new CheckoutPage();
        checkoutPage.fillBillingDetails(
                "John", "Doe",
                ConfigReader.getUsername(),
                "Test Corp",
                "South Africa", "Other",
                "Cape Town", "123 Test Street",
                "8001", "0210000000"
        );
        checkoutPage.continueShipping();

        // ── Step 7: Payment Method — Cash on Delivery ─────────────────────────
        ExtentReportManager.getTest().info("Step 7: Selecting Cash on Delivery");
        checkoutPage.selectCashOnDelivery();
        checkoutPage.continuePaymentInfo();

        // ── Step 8: Confirm Order ─────────────────────────────────────────────
        ExtentReportManager.getTest().info("Step 8: Confirming order");
        checkoutPage.confirmOrder();

        // ── Step 9: Verify & Capture Order Number ─────────────────────────────
        ExtentReportManager.getTest().info("Step 9: Verifying order completion");
        Assert.assertTrue(checkoutPage.isOrderConfirmed(),
                "Order completion page should be displayed");

        String orderNumber = checkoutPage.getOrderNumber();
        Assert.assertFalse(orderNumber.isEmpty(), "Order number should not be empty");

        log.info("════════════════════════════════════════════");
        log.info("  ORDER PLACED SUCCESSFULLY");
        log.info("  Order Number: {}", orderNumber);
        log.info("════════════════════════════════════════════");

        ExtentReportManager.getTest().pass("Order placed successfully. Order Number: " + orderNumber);
    }

    @Test(
        groups      = {"regression"},
        description = "Verify cart is empty for a new session without adding products"
    )
    public void emptyCartTest() {
        ExtentReportManager.getTest().info("Navigating directly to cart");
        ShoppingCartPage cartPage = new ShoppingCartPage();
        cartPage.open();

        Assert.assertTrue(cartPage.isCartPageDisplayed(), "Cart page should be displayed");
        Assert.assertEquals(cartPage.getCartItemCount(), 0,
                "Cart should be empty for a fresh session");
        ExtentReportManager.getTest().pass("Cart is empty as expected");
    }
}
