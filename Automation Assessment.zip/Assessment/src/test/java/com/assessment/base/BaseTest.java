package com.assessment.base;

import com.aventstack.extentreports.Status;
import com.assessment.config.ConfigReader;
import com.assessment.utils.DriverManager;
import com.assessment.utils.ExtentReportManager;
import com.assessment.utils.ScreenshotUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.lang.reflect.Method;

/**
 * BaseTest
 * Parent class for all Test classes.
 * Handles: driver lifecycle, Extent Report wiring, screenshot on failure.
 *
 * All Test classes extend this — never instantiate it directly.
 */
public class BaseTest {

    protected static final Logger log = LogManager.getLogger(BaseTest.class);

    // ── Suite ─────────────────────────────────────────────────────────────────

    @BeforeSuite(alwaysRun = true)
    public void suiteSetup() {
        log.info("══════════════ SUITE STARTED ══════════════");
        ExtentReportManager.getInstance();
    }

    @AfterSuite(alwaysRun = true)
    public void suiteTeardown() {
        ExtentReportManager.flush();
        log.info("══════════════ SUITE COMPLETE | Report → {} ══════════════",
                ConfigReader.getReportPath());
    }

    // ── Test ──────────────────────────────────────────────────────────────────

    @BeforeMethod(alwaysRun = true)
    public void testSetup(Method method) {
        String name = method.getName();
        String desc = method.isAnnotationPresent(Test.class)
                ? method.getAnnotation(Test.class).description() : "";

        log.info("── TEST START: {} ──", name);

        DriverManager.initDriver();
        DriverManager.getDriver().get(ConfigReader.getBaseUrl());

        ExtentReportManager.createTest(name, desc);
        ExtentReportManager.getTest().log(Status.INFO,
                "Browser: " + ConfigReader.getBrowser() + " | URL: " + ConfigReader.getBaseUrl());
    }

    @AfterMethod(alwaysRun = true)
    public void testTeardown(ITestResult result) {
        switch (result.getStatus()) {

            case ITestResult.SUCCESS:
                ExtentReportManager.getTest().pass("✅ PASSED: " + result.getName());
                log.info("✅ PASSED: {}", result.getName());
                break;

            case ITestResult.FAILURE:
                String errMsg = result.getThrowable().getMessage();
                if (ConfigReader.screenshotOnFail()) {
                    ExtentReportManager.getTest()
                            .fail("❌ FAILED: " + errMsg)
                            .addScreenCaptureFromBase64String(
                                    ScreenshotUtil.captureAsBase64(), "Failure Screenshot");
                } else {
                    ExtentReportManager.getTest().fail(result.getThrowable());
                }
                log.error("❌ FAILED: {} — {}", result.getName(), errMsg);
                break;

            case ITestResult.SKIP:
                ExtentReportManager.getTest().skip("⚠️ SKIPPED: " + result.getName());
                log.warn("⚠️ SKIPPED: {}", result.getName());
                break;
        }

        DriverManager.quitDriver();
        log.info("── TEST END: {} ──", result.getName());
    }
}
