package com.assessment.base;

import com.assessment.utils.DriverManager;
import com.assessment.utils.WaitUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * BasePage
 * Parent class for all Page Objects.
 * Provides reusable, logged wrappers for common WebDriver interactions.
 *
 * All Page Objects extend this class — never instantiate it directly.
 */
public class BasePage {

    protected final WebDriver driver;
    protected final Logger    log;

    protected BasePage() {
        this.driver = DriverManager.getDriver();
        this.log    = LogManager.getLogger(getClass());
        PageFactory.initElements(driver, this);
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    protected void navigateTo(String url)     { log.info("Navigate to: {}", url); driver.get(url); }
    protected String getCurrentUrl()          { return driver.getCurrentUrl(); }
    protected String getPageTitle()           { return driver.getTitle(); }

    // ── Click ─────────────────────────────────────────────────────────────────

    protected void click(By locator) {
        log.debug("Click: {}", locator);
        WaitUtil.waitForClickable(driver, locator).click();
    }

    protected void click(WebElement element) {
        log.debug("Click element");
        WaitUtil.waitForClickable(driver, element).click();
    }

    protected void jsClick(WebElement element) {
        log.debug("JS click");
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }

    // ── Input ─────────────────────────────────────────────────────────────────

    protected void type(By locator, String text) {
        log.debug("Type '{}' into: {}", text, locator);
        WebElement el = WaitUtil.waitForVisible(driver, locator);
        el.clear();
        el.sendKeys(text);
    }

    protected void type(WebElement element, String text) {
        log.debug("Type '{}'", text);
        WaitUtil.waitForVisible(driver, element);
        element.clear();
        element.sendKeys(text);
    }

    // ── Dropdowns ─────────────────────────────────────────────────────────────

    protected void selectByText(By locator, String text) {
        new Select(WaitUtil.waitForVisible(driver, locator)).selectByVisibleText(text);
    }

    protected void selectByText(WebElement element, String text) {
        new Select(element).selectByVisibleText(text);
    }

    protected void selectByValue(By locator, String value) {
        new Select(WaitUtil.waitForVisible(driver, locator)).selectByValue(value);
    }

    protected void selectByIndex(By locator, int index) {
        new Select(WaitUtil.waitForVisible(driver, locator)).selectByIndex(index);
    }

    // ── Read ──────────────────────────────────────────────────────────────────

    protected String getText(By locator)              { return WaitUtil.waitForVisible(driver, locator).getText().trim(); }
    protected String getText(WebElement el)           { return WaitUtil.waitForVisible(driver, el).getText().trim(); }
    protected String getAttribute(By locator, String attr) { return WaitUtil.waitForVisible(driver, locator).getAttribute(attr); }

    // ── State ─────────────────────────────────────────────────────────────────

    protected boolean isDisplayed(By locator) {
        try { return driver.findElement(locator).isDisplayed(); }
        catch (NoSuchElementException | StaleElementReferenceException e) { return false; }
    }

    protected boolean isEnabled(By locator) {
        try { return driver.findElement(locator).isEnabled(); }
        catch (Exception e) { return false; }
    }

    protected boolean isSelected(WebElement element) { return element.isSelected(); }

    // ── Collections ───────────────────────────────────────────────────────────

    protected List<WebElement> findAll(By locator) { return driver.findElements(locator); }

    // ── Scroll ────────────────────────────────────────────────────────────────

    protected void scrollTo(WebElement el)  { ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", el); }
    protected void scrollToTop()            { ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,0);"); }
    protected void scrollToBottom()         { ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,document.body.scrollHeight);"); }

    // ── Hover ─────────────────────────────────────────────────────────────────

    protected void hoverOver(WebElement element) { new Actions(driver).moveToElement(element).perform(); }

    // ── Alerts ────────────────────────────────────────────────────────────────

    protected void  acceptAlert()      { driver.switchTo().alert().accept(); }
    protected void  dismissAlert()     { driver.switchTo().alert().dismiss(); }
    protected String getAlertText()    { return driver.switchTo().alert().getText(); }

    // ── Frames ────────────────────────────────────────────────────────────────

    protected void switchToFrame(By locator)     { driver.switchTo().frame(driver.findElement(locator)); }
    protected void switchToDefaultContent()      { driver.switchTo().defaultContent(); }

    // ── Waits ─────────────────────────────────────────────────────────────────

    protected WebElement waitForVisible(By locator)    { return WaitUtil.waitForVisible(driver, locator); }
    protected WebElement waitForClickable(By locator)  { return WaitUtil.waitForClickable(driver, locator); }
    protected boolean    waitForUrl(String partial)    { return WaitUtil.waitForUrlContains(driver, partial); }
}
