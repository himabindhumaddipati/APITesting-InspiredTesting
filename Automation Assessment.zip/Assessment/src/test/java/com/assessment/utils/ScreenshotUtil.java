package com.assessment.utils;

import com.assessment.config.ConfigReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * ScreenshotUtil
 * Captures screenshots on test failure.
 * Saves PNG to test-output/screenshots/ and returns Base64 for Extent Reports.
 */
public class ScreenshotUtil {

    private static final Logger log = LogManager.getLogger(ScreenshotUtil.class);

    private ScreenshotUtil() { }

    public static String capture(String testName) {
        try {
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String fileName  = testName + "_" + timestamp + ".png";
            Path   dir       = Paths.get(ConfigReader.getScreenshotPath());

            if (!Files.exists(dir)) Files.createDirectories(dir);

            File   src  = ((TakesScreenshot) DriverManager.getDriver()).getScreenshotAs(OutputType.FILE);
            Path   dest = dir.resolve(fileName);
            Files.copy(src.toPath(), dest);

            log.info("Screenshot saved: {}", dest.toAbsolutePath());
            return dest.toAbsolutePath().toString();

        } catch (IOException e) {
            log.error("Screenshot capture failed for: {}", testName, e);
            return "";
        }
    }

    public static String captureAsBase64() {
        return ((TakesScreenshot) DriverManager.getDriver())
                .getScreenshotAs(OutputType.BASE64);
    }
}
