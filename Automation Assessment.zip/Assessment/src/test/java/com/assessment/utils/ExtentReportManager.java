package com.assessment.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.assessment.config.ConfigReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

/**
 * ExtentReportManager
 * Singleton HTML report manager.
 * Creates one report per suite run; each test gets its own node.
 */
public class ExtentReportManager {

    private static final Logger log = LogManager.getLogger(ExtentReportManager.class);

    private static ExtentReports                  extent;
    private static final ThreadLocal<ExtentTest>  testNode = new ThreadLocal<>();

    private ExtentReportManager() { }

    public static synchronized ExtentReports getInstance() {
        if (extent == null) {
            String reportPath = ConfigReader.getReportPath();
            new File(reportPath).getParentFile().mkdirs();

            ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
            spark.config().setTheme(Theme.DARK);
            spark.config().setDocumentTitle("Assessment Test Report");
            spark.config().setReportName("Selenium Java Framework — Assessment");
            spark.config().setEncoding("UTF-8");

            extent = new ExtentReports();
            extent.attachReporter(spark);
            extent.setSystemInfo("OS",      System.getProperty("os.name"));
            extent.setSystemInfo("Java",    System.getProperty("java.version"));
            extent.setSystemInfo("Browser", ConfigReader.getBrowser());
            extent.setSystemInfo("Author",  "Assessment Candidate");

            log.info("ExtentReports initialised: {}", reportPath);
        }
        return extent;
    }

    public static void createTest(String name, String description) {
        testNode.set(getInstance().createTest(name, description));
    }

    public static ExtentTest getTest() {
        return testNode.get();
    }

    public static synchronized void flush() {
        if (extent != null) {
            extent.flush();
            log.info("Report flushed to: {}", ConfigReader.getReportPath());
        }
    }
}
