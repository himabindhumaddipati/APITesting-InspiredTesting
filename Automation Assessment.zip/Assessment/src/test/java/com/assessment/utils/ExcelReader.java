package com.assessment.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * ExcelReader
 * Reads test data from .xlsx files using Apache POI.
 * First row is treated as the header row.
 *
 * Usage:
 *   List<Map<String,String>> rows = ExcelReader.getData("src/test/resources/testdata/LoginData.xlsx", "Sheet1");
 *   String username = rows.get(0).get("username");
 */
public class ExcelReader {

    private static final Logger log = LogManager.getLogger(ExcelReader.class);

    private ExcelReader() { }

    public static List<Map<String, String>> getData(String filePath, String sheetName) {
        List<Map<String, String>> data = new ArrayList<>();

        try (FileInputStream fis  = new FileInputStream(filePath);
             Workbook workbook    = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) throw new RuntimeException("Sheet not found: " + sheetName);

            Row    header   = sheet.getRow(0);
            int    colCount = header.getLastCellNum();

            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) continue;

                Map<String, String> rowData = new LinkedHashMap<>();
                for (int c = 0; c < colCount; c++) {
                    String key   = cellValue(header.getCell(c));
                    String value = cellValue(row.getCell(c));
                    rowData.put(key, value);
                }
                data.add(rowData);
            }

            log.info("Read {} rows from {}[{}]", data.size(), filePath, sheetName);

        } catch (IOException e) {
            throw new RuntimeException("Failed to read Excel: " + filePath, e);
        }

        return data;
    }

    private static String cellValue(Cell cell) {
        return cell == null ? "" : new DataFormatter().formatCellValue(cell).trim();
    }
}
