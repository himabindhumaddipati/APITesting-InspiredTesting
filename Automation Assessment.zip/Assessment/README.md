# Selenium Java Automation Framework
### Assessment Submission

---

## 📋 Task Covered
End-to-end automation of **https://demowebshop.tricentis.com**:

1. Login with registered credentials
2. Navigate Computers → Desktops
3. Select "Build your own cheap computer"
4. Add to Cart
5. Accept Terms & Conditions → Checkout
6. Complete Billing & Shipping details
7. Select Cash on Delivery payment
8. Confirm Order
9. Capture and assert Order Number

---

## 🏗️ Framework Architecture

```
selenium-assessment/
│
├── pom.xml                          ← Maven dependencies
├── testng.xml                       ← Suite configuration (smoke + regression)
│
└── src/test/
    ├── java/com/assessment/
    │   │
    │   ├── base/
    │   │   ├── BasePage.java        ← Parent for all Page Objects
    │   │   └── BaseTest.java        ← Parent for all Tests (driver + reports)
    │   │
    │   ├── config/
    │   │   └── ConfigReader.java    ← Reads config.properties
    │   │
    │   ├── listeners/
    │   │   └── TestListener.java    ← TestNG event logging
    │   │
    │   ├── pages/                   ← Page Object Model (POM)
    │   │   ├── LoginPage.java
    │   │   ├── HomePage.java
    │   │   ├── ProductPage.java
    │   │   ├── ShoppingCartPage.java
    │   │   └── CheckoutPage.java
    │   │
    │   ├── tests/                   ← Test classes
    │   │   ├── LoginTest.java       ← Login scenarios
    │   │   └── ShoppingCartTest.java ← End-to-end purchase + cart tests
    │   │
    │   └── utils/
    │       ├── DriverManager.java   ← ThreadLocal WebDriver (Chrome/Firefox/Edge)
    │       ├── WaitUtil.java        ← Explicit wait helpers
    │       ├── ScreenshotUtil.java  ← Failure screenshots → Extent Report
    │       ├── ExcelReader.java     ← Apache POI data-driven support
    │       └── ExtentReportManager.java ← HTML report singleton
    │
    └── resources/
        ├── config/
        │   └── config.properties    ← URL, credentials, timeouts, browser
        ├── testdata/
        │   └── LoginData.csv        ← Sample data-driven test data
        └── log4j2.xml               ← Logging configuration
```

---

## ⚙️ Design Patterns Used

| Pattern               | Where Applied                          |
|-----------------------|----------------------------------------|
| Page Object Model     | All classes in `pages/`               |
| Singleton             | `ExtentReportManager`                 |
| Factory               | `DriverManager` (browser switching)   |
| ThreadLocal           | `DriverManager` (parallel-safe)       |
| Inheritance           | `BasePage` → Pages, `BaseTest` → Tests|

---

## 🛠️ Tech Stack

| Tool              | Version  | Purpose                        |
|-------------------|----------|--------------------------------|
| Java              | 11       | Language                       |
| Selenium          | 4.18.1   | Browser automation             |
| TestNG            | 7.9.0    | Test runner + assertions       |
| WebDriverManager  | 5.7.0    | Auto driver management         |
| Extent Reports    | 5.1.1    | HTML reports with screenshots  |
| Apache POI        | 5.2.5    | Excel data-driven testing      |
| Log4j2            | 2.23.0   | Console + file logging         |

---

## 🚀 How to Run

### Prerequisites
- Java 11+
- Maven 3.8+
- Google Chrome (latest)

### Run all tests
```bash
mvn test
```

### Run with credentials
```bash
mvn test -Dapp.username=you@email.com -Dapp.password=YourPassword123
```

### Run headless (CI)
```bash
mvn test -Dheadless=true
```

### Run smoke tests only
```bash
mvn test -Dgroups=smoke
```

### Run on Firefox
```bash
mvn test -Dbrowser=firefox
```

---

## 📊 Reports & Logs

| Output | Location |
|--------|----------|
| HTML Report | `test-output/ExtentReport.html` |
| Log File | `test-output/automation.log` |
| Screenshots | `test-output/screenshots/` |

---

## 🔑 Precondition
Register your account at https://demowebshop.tricentis.com/register
then update `src/test/resources/config/config.properties` with your credentials.
