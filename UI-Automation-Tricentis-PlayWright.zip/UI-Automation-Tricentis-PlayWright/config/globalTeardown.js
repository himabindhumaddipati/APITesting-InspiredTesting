// config/globalTeardown.js
module.exports = async function globalTeardown() {
  console.log('\n✅ Global Teardown — all done.\n');
  // Add any cleanup here: DB reset, temp file removal, etc.
};
