// config/globalSetup.js
const fs = require('fs');
const path = require('path');

module.exports = async function globalSetup() {
  console.log('\n🚀 Global Setup — Playwright Automation Framework\n');

  // Ensure report directories exist
  const dirs = [
    'reports/html',
    'reports/artifacts',
    'reports/screenshots',
  ];
  dirs.forEach((dir) => {
    fs.mkdirSync(path.join(process.cwd(), dir), { recursive: true });
  });

  // Log environment info
  console.log(`  ENV:      ${process.env.NODE_ENV || 'local'}`);
  console.log(`  BASE_URL: ${process.env.BASE_URL || 'https://playwright.dev'}`);
  console.log(`  CI:       ${process.env.CI ? 'yes' : 'no'}`);
  console.log('');
};
