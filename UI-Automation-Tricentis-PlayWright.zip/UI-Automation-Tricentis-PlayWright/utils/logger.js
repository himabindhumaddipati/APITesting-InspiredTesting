// utils/logger.js
const { createLogger, format, transports } = require('winston');
const path = require('path');

const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: format.combine(
    format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    format.errors({ stack: true }),
    format.printf(({ timestamp, level, message, stack }) => {
      const lvl = level.toUpperCase().padEnd(5);
      return stack
        ? `[${timestamp}] ${lvl} ${message}\n${stack}`
        : `[${timestamp}] ${lvl} ${message}`;
    })
  ),
  transports: [
    // Console — coloured for readability
    new transports.Console({
      format: format.combine(format.colorize(), format.simple()),
    }),
    // File — plain text, full detail
    new transports.File({
      filename: path.join('reports', 'automation.log'),
      maxsize: 5_000_000, // 5 MB
      maxFiles: 3,
      tailable: true,
    }),
  ],
});

module.exports = logger;
