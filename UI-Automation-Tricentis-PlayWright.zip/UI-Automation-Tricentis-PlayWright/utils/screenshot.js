// utils/screenshot.js
const path = require('path');
const fs   = require('fs');

// Project root — two levels up from utils/
const ROOT = path.resolve(__dirname, '..');

/**
 * Saves a named screenshot to reports/screenshots/<testTitle>/Step_NN_<desc>.png
 * AND attaches it to the Playwright HTML report with a readable label.
 *
 * @param {import('@playwright/test').Page}     page
 * @param {import('@playwright/test').TestInfo} testInfo
 * @param {number} stepNum     - sequential step number within the test
 * @param {string} description - human-readable step label
 */
async function captureStep(page, testInfo, stepNum, description) {
  // Build a safe folder name from the test title (e.g. "TC04_@smoke_buy_a_desktop...")
  const safeName  = testInfo.title.replace(/[^a-zA-Z0-9]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
  const safeDesc  = description.replace(/[^a-zA-Z0-9\s]/g, '').trim().replace(/\s+/g, '_');
  const filename  = `Step_${String(stepNum).padStart(2, '0')}_${safeDesc}.png`;
  const dir       = path.join(ROOT, 'reports', 'screenshots', safeName);

  fs.mkdirSync(dir, { recursive: true });

  const filePath  = path.join(dir, filename);
  const buffer    = await page.screenshot({ path: filePath, fullPage: false });

  // Also wire into the HTML report so screenshots appear inline
  const label = `Step ${String(stepNum).padStart(2, '0')} — ${description}`;
  await testInfo.attach(label, { body: buffer, contentType: 'image/png' });
}

module.exports = { captureStep };
