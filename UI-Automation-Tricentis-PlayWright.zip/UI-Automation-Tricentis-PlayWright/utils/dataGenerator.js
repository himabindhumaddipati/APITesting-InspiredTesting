// utils/dataGenerator.js

/**
 * Generates random test data without external dependencies.
 * Use this to avoid test pollution from hardcoded values.
 */
class DataGenerator {
  /**
   * Random email with timestamp suffix to ensure uniqueness
   */
  static email(prefix = 'test') {
    return `${prefix}.${Date.now()}@qa.example.com`;
  }

  /**
   * Random string of given length
   */
  static string(length = 8) {
    return Math.random().toString(36).substring(2, 2 + length);
  }

  /**
   * Random integer between min and max (inclusive)
   */
  static int(min = 1, max = 100) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  /**
   * Random phone number (SA format by default)
   */
  static phone(countryCode = '+27') {
    const digits = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10)).join('');
    return `${countryCode}${digits}`;
  }

  /**
   * Random full name
   */
  static fullName() {
    const first = ['Alice', 'Bob', 'Carol', 'Dan', 'Eve', 'Frank', 'Grace'];
    const last  = ['Smith', 'Jones', 'Williams', 'Brown', 'Taylor', 'Wilson'];
    return `${first[this.int(0, first.length - 1)]} ${last[this.int(0, last.length - 1)]}`;
  }

  /**
   * Random password meeting common complexity rules
   */
  static password(length = 12) {
    const upper   = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lower   = 'abcdefghijklmnopqrstuvwxyz';
    const digits  = '0123456789';
    const special = '!@#$%^&*';
    const all     = upper + lower + digits + special;

    const pick = (s) => s[Math.floor(Math.random() * s.length)];
    const base = [pick(upper), pick(lower), pick(digits), pick(special)];
    const rest = Array.from({ length: length - 4 }, () => pick(all));

    return [...base, ...rest].sort(() => Math.random() - 0.5).join('');
  }

  /**
   * ISO date string, offset by days from today
   */
  static dateOffset(days = 0) {
    const d = new Date();
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  }

  /**
   * Build a complete user payload
   */
  static user(overrides = {}) {
    return {
      name:     this.fullName(),
      email:    this.email(),
      password: this.password(),
      phone:    this.phone(),
      ...overrides,
    };
  }
}

module.exports = { DataGenerator };
