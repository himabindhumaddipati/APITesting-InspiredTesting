# Playwright Automation Framework — JavaScript

A production-grade, enterprise-ready test automation framework built with [Playwright](https://playwright.dev/).

---

## Features

- **Page Object Model (POM)** with a reusable BasePage
- **Custom Fixtures** for dependency injection (no manual imports)
- **E2E, API & Visual regression** testing in one framework
- **Multi-browser** support: Chromium, Firefox, WebKit, Mobile
- **Parallel execution** with configurable sharding
- **Auth state reuse** — login once, run all tests
- **Winston logging** with file + console output
- **GitHub Actions CI** with sharding + report merging

---

## Project Structure

```
playwright-framework/
├── config/
│   ├── globalSetup.js        # Runs before all tests
│   └── globalTeardown.js     # Runs after all tests
├── fixtures/
│   ├── index.js              # Custom test fixtures (POM injection)
│   ├── testData.json         # Static test data
│   └── auth.json             # Generated — saved auth state (git-ignored)
├── pages/
│   ├── BasePage.js           # Base class with shared helpers
│   └── LoginPage.js          # Example page object
├── tests/
│   ├── auth.setup.js         # Auth setup (runs before all projects)
│   ├── e2e/                  # End-to-end browser tests
│   ├── api/                  # API tests (no browser)
│   └── visual/               # Visual regression tests
├── utils/
│   ├── logger.js             # Winston logger
│   └── dataGenerator.js      # Random test data generator
├── reports/                  # Generated test reports (git-ignored)
├── .env.example              # Environment variable template
├── playwright.config.js      # Main configuration
└── package.json
```

---

## Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Install browsers
npx playwright install

# 3. Configure environment
cp .env.example .env
# Edit .env with your BASE_URL, credentials, etc.

# 4. Run tests
npm test
```

---

## Common Commands

| Command | Description |
|---|---|
| `npm test` | Run all tests |
| `npm run test:e2e` | E2E tests only |
| `npm run test:api` | API tests only |
| `npm run test:visual` | Visual regression tests |
| `npm run test:smoke` | Tests tagged `@smoke` |
| `npm run test:regression` | Tests tagged `@regression` |
| `npm run test:headed` | Run with browser visible |
| `npm run test:debug` | Step through with Playwright Inspector |
| `npm run test:ui` | Open Playwright UI mode |
| `npm run test:report` | Open the HTML report |
| `npm run codegen` | Record tests with Codegen |

---

## Writing Tests

### Tag tests for selective runs
```js
test('@smoke login works', async ({ loginPage }) => { ... });
test('@regression edge case', async ({ page }) => { ... });
```

### Use the custom fixtures (POM auto-injected)
```js
const { test, expect } = require('../../fixtures/index');

test('my test', async ({ loginPage, apiContext, testData }) => {
  await loginPage.navigate();
  await loginPage.login(testData.users.admin.username, testData.users.admin.password);
});
```

### Generate random data
```js
const { DataGenerator } = require('../../utils/dataGenerator');

const user = DataGenerator.user({ role: 'admin' });
```

---

## Visual Regression

```bash
# Generate baseline snapshots (first run)
npx playwright test tests/visual/ --update-snapshots

# Compare against baseline
npx playwright test tests/visual/
```

---

## CI / CD

Push to `main` or `develop` triggers the GitHub Actions workflow.
Tests run in **4 parallel shards**, reports are merged and uploaded as artifacts.

Configure these GitHub Secrets:
- `BASE_URL`
- `TEST_USERNAME`
- `TEST_PASSWORD`
- `API_TOKEN`
