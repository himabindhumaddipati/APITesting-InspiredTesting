// tests/e2e/purchase.spec.js
const { test, expect } = require('../../fixtures/index');
const testData = require('../../fixtures/testData.json');
const { captureStep } = require('../../utils/screenshot');

/**
 * Full end-to-end purchase flow:
 * Login → Browse → Add to Cart → Checkout → Confirm
 *
 * Mirrors the original Java assessment test flow exactly.
 */
test.describe('Purchase Flow — Tricentis Demo WebShop', () => {

  test.beforeEach(async ({ homePage, loginPage, shoppingCartPage }) => {
    await homePage.open();
    await loginPage.login(
      testData.users.standard.email,
      testData.users.standard.password
    );
    // Clear any leftover cart items from a previous failed run
    await shoppingCartPage.clearCart();
    await homePage.open();
  });

  // ── TC04: Desktop purchase ────────────────────────────────────

  test('TC04 @smoke buy a desktop computer end-to-end', async ({
    page, homePage, productPage, shoppingCartPage, checkoutPage
  }, testInfo) => {

    // Step 1 — Navigate to Desktops
    await homePage.navigateToDesktops();
    await captureStep(page, testInfo, 1, 'TC04 — Desktops category page');

    // Step 2 — Select product
    await productPage.selectProductByName(testData.products.desktop);
    const loaded = await productPage.isProductDetailLoaded();
    expect(loaded).toBeTruthy();
    await captureStep(page, testInfo, 2, 'TC04 — Product detail page (Build your own computer)');

    // Step 3 — Add to cart
    await productPage.addToCart();
    const added = await productPage.isAddToCartSuccessful();
    expect(added).toBeTruthy();
    await captureStep(page, testInfo, 3, 'TC04 — Add to cart success notification');

    // Step 4 — Go to cart
    await shoppingCartPage.open();
    const cartDisplayed = await shoppingCartPage.isCartPageDisplayed();
    expect(cartDisplayed).toBeTruthy();
    const itemCount = await shoppingCartPage.getCartItemCount();
    expect(itemCount).toBeGreaterThan(0);
    await captureStep(page, testInfo, 4, 'TC04 — Shopping cart with desktop item');

    // Step 5 — Accept T&Cs and checkout
    await shoppingCartPage.acceptTermsAndConditions();
    await shoppingCartPage.clickCheckout(
      testData.users.standard.email,
      testData.users.standard.password
    );
    await captureStep(page, testInfo, 5, 'TC04 — Checkout billing address step');

    // Step 6 — Billing
    await checkoutPage.fillBillingDetails(testData.billing);
    await captureStep(page, testInfo, 6, 'TC04 — Billing address completed');

    // Step 7 — Shipping (address + method)
    await checkoutPage.continueShipping();
    await captureStep(page, testInfo, 7, 'TC04 — Shipping method selected');

    // Step 8 — Payment method
    await checkoutPage.selectCashOnDelivery();
    await captureStep(page, testInfo, 8, 'TC04 — Payment method (Cash on Delivery)');

    // Step 9 — Payment info
    await checkoutPage.continuePaymentInfo();
    await captureStep(page, testInfo, 9, 'TC04 — Payment information confirmed');

    // Step 10 — Confirm order page (before submit)
    await captureStep(page, testInfo, 10, 'TC04 — Confirm order page (pre-submit)');
    await checkoutPage.confirmOrder();

    // Step 11 — Order completed
    const confirmed = await checkoutPage.isOrderConfirmed();
    expect(confirmed).toBeTruthy();
    await captureStep(page, testInfo, 11, 'TC04 — Order completed (Thank You page)');

    const orderNumber = await checkoutPage.getOrderNumber();
    expect(orderNumber.length).toBeGreaterThan(0);
    console.log(`✅ TC04 Order placed successfully. Order #${orderNumber}`);
  });

  // ── TC05: Notebook purchase ───────────────────────────────────

  test('TC05 @regression buy a notebook end-to-end', async ({
    page, homePage, productPage, shoppingCartPage, checkoutPage
  }, testInfo) => {

    // Step 1 — Navigate to Notebooks
    await homePage.navigateToNotebooks();
    await captureStep(page, testInfo, 1, 'TC05 — Notebooks category page');

    // Step 2 — Select product
    await productPage.selectProductByName(testData.products.notebook);
    const loaded = await productPage.isProductDetailLoaded();
    expect(loaded).toBeTruthy();
    await captureStep(page, testInfo, 2, 'TC05 — Product detail page (14.1-inch Laptop)');

    // Step 3 — Add to cart
    await productPage.addToCart();
    const added = await productPage.isAddToCartSuccessful();
    expect(added).toBeTruthy();
    await captureStep(page, testInfo, 3, 'TC05 — Add to cart success notification');

    // Step 4 — Go to cart
    await shoppingCartPage.open();
    const itemCount = await shoppingCartPage.getCartItemCount();
    expect(itemCount).toBeGreaterThan(0);
    await captureStep(page, testInfo, 4, 'TC05 — Shopping cart with notebook item');

    // Step 5 — Accept T&Cs and checkout
    await shoppingCartPage.acceptTermsAndConditions();
    await shoppingCartPage.clickCheckout(
      testData.users.standard.email,
      testData.users.standard.password
    );
    await captureStep(page, testInfo, 5, 'TC05 — Checkout billing address step');

    // Step 6 — Billing
    await checkoutPage.fillBillingDetails(testData.billing);
    await captureStep(page, testInfo, 6, 'TC05 — Billing address completed');

    // Step 7 — Shipping
    await checkoutPage.continueShipping();
    await captureStep(page, testInfo, 7, 'TC05 — Shipping method selected');

    // Step 8 — Payment method
    await checkoutPage.selectCashOnDelivery();
    await captureStep(page, testInfo, 8, 'TC05 — Payment method (Cash on Delivery)');

    // Step 9 — Payment info
    await checkoutPage.continuePaymentInfo();
    await captureStep(page, testInfo, 9, 'TC05 — Payment information confirmed');

    // Step 10 — Confirm order page (before submit)
    await captureStep(page, testInfo, 10, 'TC05 — Confirm order page (pre-submit)');
    await checkoutPage.confirmOrder();

    // Step 11 — Order completed
    const confirmed = await checkoutPage.isOrderConfirmed();
    expect(confirmed).toBeTruthy();
    await captureStep(page, testInfo, 11, 'TC05 — Order completed (Thank You page)');

    const orderNumber = await checkoutPage.getOrderNumber();
    expect(orderNumber.length).toBeGreaterThan(0);
    console.log(`✅ TC05 Order placed successfully. Order #${orderNumber}`);
  });
});
