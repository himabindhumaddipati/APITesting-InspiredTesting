// tests/e2e/login.spec.js
const { test, expect } = require('../../fixtures/index');
const testData = require('../../fixtures/testData.json');
const { captureStep } = require('../../utils/screenshot');

test.describe('Login — Tricentis Demo WebShop', () => {

  test.beforeEach(async ({ homePage }) => {
    await homePage.open();
  });

  // ── TC01: Happy path login ────────────────────────────────────

  test('TC01 @smoke valid login redirects and shows account', async ({ page, loginPage }, testInfo) => {
    await captureStep(page, testInfo, 1, 'TC01 — Home page before login');

    await loginPage.login(
      testData.users.standard.email,
      testData.users.standard.password
    );
    await captureStep(page, testInfo, 2, 'TC01 — After login (logged-in header)');

    const loggedIn = await loginPage.isLoggedIn();
    expect(loggedIn).toBeTruthy();
    await captureStep(page, testInfo, 3, 'TC01 — Login verified');
  });

  // ── TC02: Account link visible ───────────────────────────────

  test('TC02 logged-in account link is displayed in header', async ({ page, loginPage }, testInfo) => {
    await captureStep(page, testInfo, 1, 'TC02 — Home page before login');

    await loginPage.login(
      testData.users.standard.email,
      testData.users.standard.password
    );
    await captureStep(page, testInfo, 2, 'TC02 — After login');

    // Tricentis shows the user's email address as the account link when logged in
    const user = await loginPage.getLoggedInUser();
    expect(user.trim()).toBe(testData.users.standard.email);
    await captureStep(page, testInfo, 3, 'TC02 — Account email link confirmed');
  });

  // ── TC03: Invalid credentials error ──────────────────────────

  test('TC03 @regression invalid credentials shows error', async ({ page, loginPage }, testInfo) => {
    await captureStep(page, testInfo, 1, 'TC03 — Home page before login attempt');

    await loginPage.login(
      testData.users.invalid.email,
      testData.users.invalid.password
    );
    await captureStep(page, testInfo, 2, 'TC03 — Login submitted with invalid credentials');

    const error = await loginPage.getValidationError();
    expect(error.length).toBeGreaterThan(0);
    await captureStep(page, testInfo, 3, 'TC03 — Validation error displayed');
  });
});
