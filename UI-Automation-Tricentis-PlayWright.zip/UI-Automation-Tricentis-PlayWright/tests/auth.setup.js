// tests/auth.setup.js
// Not used for Tricentis Demo WebShop.
// Auth setup will be re-enabled when testing apps that require saved sessions.
