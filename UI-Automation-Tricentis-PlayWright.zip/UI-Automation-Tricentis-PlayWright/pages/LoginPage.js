// pages/LoginPage.js
const { BasePage } = require('./BasePage');

// ── Selectors (replaces @FindBy annotations) ──────────────────
const SEL = {
  loginNavLink:    'a[href="/login"]',
  emailInput:      '#Email',
  passwordInput:   '#Password',
  loginButton:     'input.login-button',
  // Tricentis shows the user's email as a link + a "Log out" link when logged in.
  // The logout link is the most reliable logged-in indicator.
  logoutLink:      'a[href="/logout"]',
  // The header account link shows the user's email text (footer has a second one — scope to header).
  accountInfoLink: '.header-links a[href="/customer/info"]',
  validationError: '.validation-summary-errors',
};

/**
 * LoginPage
 * Converted from Java Selenium → Playwright JS
 * Target: https://demowebshop.tricentis.com/login
 */
class LoginPage extends BasePage {
  constructor(page) {
    super(page);
  }

  // ── Actions ───────────────────────────────────────────────────

  async clickLoginLink() {
    await this.click(SEL.loginNavLink);
  }

  async enterEmail(email) {
    await this.type(SEL.emailInput, email);
  }

  async enterPassword(password) {
    await this.type(SEL.passwordInput, password);
  }

  async clickLoginButton() {
    await this.click(SEL.loginButton);
    // Wait for page to finish loading after form submit
    await this.page.waitForLoadState('networkidle');
  }

  /** Full login flow — replaces login(email, password) in Java */
  async login(email, password) {
    await this.clickLoginLink();
    await this.page.waitForLoadState('domcontentloaded');
    await this.enterEmail(email);
    await this.enterPassword(password);
    await this.clickLoginButton();
  }

  // ── Assertions ────────────────────────────────────────────────

  async isLoggedIn() {
    return this.isDisplayed(SEL.logoutLink);
  }

  async getValidationError() {
    const visible = await this.isDisplayed(SEL.validationError);
    return visible ? this.getText(SEL.validationError) : '';
  }

  /** Returns the email/account text shown in the header when logged in. */
  async getLoggedInUser() {
    const loggedIn = await this.isLoggedIn();
    if (!loggedIn) return '';
    return this.getText(SEL.accountInfoLink);
  }
}

module.exports = { LoginPage };
