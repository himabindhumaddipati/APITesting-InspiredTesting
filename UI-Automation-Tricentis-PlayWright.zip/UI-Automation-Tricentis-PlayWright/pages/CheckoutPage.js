// pages/CheckoutPage.js
const { BasePage } = require('./BasePage');

// ── Selectors (replaces @FindBy annotations) ──────────────────
const SEL = {
  // Billing
  firstName:       '#BillingNewAddress_FirstName',
  lastName:        '#BillingNewAddress_LastName',
  email:           '#BillingNewAddress_Email',
  company:         '#BillingNewAddress_Company',
  country:         '#BillingNewAddress_CountryId',
  state:           '#BillingNewAddress_StateProvinceId',
  city:            '#BillingNewAddress_City',
  address1:        '#BillingNewAddress_Address1',
  zip:             '#BillingNewAddress_ZipPostalCode',
  phone:           '#BillingNewAddress_PhoneNumber',
  billingContinue: '#billing-buttons-container input[type="button"]',

  // Shipping Address (step 2)
  shippingContinue: '#shipping-buttons-container input[type="button"]',

  // Shipping Method (step 3)
  shippingMethodContinue: '#shipping-method-buttons-container input[type="button"]',

  // Payment Method (step 4) — confirmed from DevTools: value="Payments.CashOnDelivery"
  cashOnDelivery: 'input[value="Payments.CashOnDelivery"]',
  paymentMethodContinue: '#payment-method-buttons-container input[type="button"]',

  // Payment Info
  paymentInfoContinue: '#payment-info-buttons-container input[type="button"]',

  // Confirm
  confirmButton: "input[value='Confirm']",

  // Complete
  orderCompleted: '.order-completed',
  orderNumber:    '.order-completed', // full container — order number parsed from text
};

/**
 * CheckoutPage
 * Converted from Java Selenium → Playwright JS
 * Multi-step: Billing → Shipping → Payment Method → Payment Info → Confirm → Complete
 */
class CheckoutPage extends BasePage {
  constructor(page) {
    super(page);
  }

  // ── Step 1: Billing ───────────────────────────────────────────

  async fillBillingDetails({ firstName, lastName, email, company,
                              country, state, city, address, zip, phone }) {
    // Wait for the billing section to load via AJAX before touching anything
    await this.waitForVisible('#billing-buttons-container', 15_000);

    // Check if the new-address form fields are already visible
    let formVisible = await this.page.locator(SEL.firstName).isVisible({ timeout: 2_000 }).catch(() => false);

    if (!formVisible) {
      // A saved address is already selected in the dropdown — just proceed.
      // Don't attempt to switch to a new address; the saved one is valid.
    }

    if (formVisible) {
      // Fill every field in the new-address form
      await this.type(SEL.firstName, firstName);
      await this.type(SEL.lastName,  lastName);
      await this.type(SEL.email,     email);
      await this.type(SEL.company,   company);
      await this.selectByText(SEL.country, country);

      // State dropdown only appears for some countries
      try {
        await this.waitForVisible(SEL.state, 3_000);
        await this.selectByText(SEL.state, state);
      } catch { /* state not required */ }

      await this.type(SEL.city,     city);
      await this.type(SEL.address1, address);
      await this.type(SEL.zip,      zip);
      await this.type(SEL.phone,    phone);
    }
    // If no new-address form appeared, a saved address is already selected — just continue

    await this.waitForClickable(SEL.billingContinue);
    await this.click(SEL.billingContinue);
  }

  // ── Step 2: Shipping Address ──────────────────────────────────

  async continueShipping() {
    // Step 2 — Shipping Address: click Continue
    await this.waitForClickable(SEL.shippingContinue);
    await this.click(SEL.shippingContinue);
    // Step 3 — Shipping Method: site shows shipping options (Ground etc.) — click Continue
    await this.waitForClickable(SEL.shippingMethodContinue);
    await this.click(SEL.shippingMethodContinue);
  }

  // ── Step 4: Payment Method ────────────────────────────────────

  async selectCashOnDelivery() {
    // Wait directly for the radio — no container ID needed
    await this.waitForVisible(SEL.cashOnDelivery, 15_000);
    if (!await this.page.locator(SEL.cashOnDelivery).isChecked()) {
      await this.jsClick(SEL.cashOnDelivery);
    }
    await this.waitForClickable(SEL.paymentMethodContinue);
    await this.click(SEL.paymentMethodContinue);
  }

  // ── Step 4: Payment Info ──────────────────────────────────────

  async continuePaymentInfo() {
    await this.waitForClickable(SEL.paymentInfoContinue);
    await this.click(SEL.paymentInfoContinue);
  }

  // ── Step 5: Confirm ───────────────────────────────────────────

  async confirmOrder() {
    await this.waitForClickable(SEL.confirmButton);
    await this.click(SEL.confirmButton);
    // ConfirmOrder.save() is an AJAX call — wait for the page to settle
    await this.page.waitForLoadState('networkidle');
  }

  // ── Assertions ────────────────────────────────────────────────

  async isOrderConfirmed() {
    try {
      await this.page.locator(SEL.orderCompleted).waitFor({ state: 'visible', timeout: 15_000 });
      return true;
    } catch {
      return false;
    }
  }

  async getOrderNumber() {
    await this.waitForVisible(SEL.orderCompleted, 15_000);
    const text = await this.getText(SEL.orderCompleted);
    // Extract the numeric order number from text like "Order number: 2329362"
    const match = text.match(/Order number[:\s]+(\d+)/i);
    return match ? match[1] : '';
  }
}

module.exports = { CheckoutPage };
