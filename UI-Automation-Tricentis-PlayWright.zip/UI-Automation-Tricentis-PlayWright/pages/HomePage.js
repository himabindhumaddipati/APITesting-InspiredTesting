// pages/HomePage.js
const { BasePage } = require('./BasePage');

// ── Selectors (replaces @FindBy annotations) ──────────────────
const SEL = {
  computersMenu:  "ul.top-menu > li > a[href='/computers']",
  desktopsLink:   "ul.top-menu a[href='/desktops']",
  notebooksLink:  "ul.top-menu a[href='/notebooks']",
  logoutLink:     "a[href='/logout']",
};

const BASE_URL = process.env.BASE_URL || 'https://demowebshop.tricentis.com';

/**
 * HomePage
 * Converted from Java Selenium → Playwright JS
 * Target: https://demowebshop.tricentis.com
 */
class HomePage extends BasePage {
  constructor(page) {
    super(page);
  }

  // ── Actions ───────────────────────────────────────────────────

  async open() {
    await this.navigateTo(BASE_URL);
  }

  async navigateToDesktops() {
    await this.click(SEL.computersMenu);
    await this.click(SEL.desktopsLink);
  }

  async navigateToNotebooks() {
    await this.click(SEL.computersMenu);
    await this.click(SEL.notebooksLink);
  }

  async logout() {
    await this.click(SEL.logoutLink);
  }

  // ── Assertions ────────────────────────────────────────────────

  isHomePageLoaded() {
    return this.getCurrentUrl().includes('demowebshop.tricentis.com');
  }
}

module.exports = { HomePage };
