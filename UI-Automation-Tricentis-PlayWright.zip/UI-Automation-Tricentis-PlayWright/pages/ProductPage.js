// pages/ProductPage.js
const { BasePage } = require('./BasePage');

// ── Selectors (replaces @FindBy annotations) ──────────────────
const SEL = {
  productTitles:       '.product-title a',
  productDetailTitle:  'h1.product-title, h1[itemprop="name"], div.product-name h1',
  addToCartButton:     "input[value='Add to cart']",
  successNotification: '.bar-notification.success',
};

/**
 * ProductPage
 * Converted from Java Selenium → Playwright JS
 * Covers both product listing and product detail pages.
 */
class ProductPage extends BasePage {
  constructor(page) {
    super(page);
  }

  // ── Listing Actions ───────────────────────────────────────────

  /**
   * Clicks the first product whose title contains productName (case-insensitive).
   * Replaces the for-loop over List<WebElement> in Java.
   */
  async selectProductByName(productName) {
    const allProducts = this.page.locator(SEL.productTitles);
    const count = await allProducts.count();

    for (let i = 0; i < count; i++) {
      const title = await allProducts.nth(i).textContent();
      if (title.toLowerCase().includes(productName.toLowerCase())) {
        await allProducts.nth(i).scrollIntoViewIfNeeded();
        await allProducts.nth(i).click();
        await this.page.waitForLoadState('domcontentloaded');
        return;
      }
    }

    throw new Error(`Product not found: ${productName}`);
  }

  // ── Detail Actions ────────────────────────────────────────────

  async getProductTitle() {
    return this.getText(SEL.productDetailTitle);
  }

  async addToCart() {
    // For configurable products (e.g. "Build your own computer"), required
    // attribute dropdowns must be set before clicking Add to Cart.
    // Auto-select the first non-empty option for every required select on the page.
    // ── Select dropdowns (e.g. RAM) ────────────────────────────────
    const selects = this.page.locator('#product-details-form select');
    const selectCount = await selects.count();
    for (let i = 0; i < selectCount; i++) {
      const sel = selects.nth(i);
      if (await sel.isVisible()) {
        const opts = sel.locator('option');
        const optCount = await opts.count();
        if (optCount > 1) {
          const val = await opts.nth(1).getAttribute('value');
          if (val) await sel.selectOption(val);
        }
      }
    }

    // ── Radio buttons (e.g. HDD, OS) ───────────────────────────────
    // Group by name and click the first radio in each group.
    const radios = this.page.locator('#product-details-form input[type="radio"]');
    const radioCount = await radios.count();
    const seenGroups = new Set();
    for (let i = 0; i < radioCount; i++) {
      const radio = radios.nth(i);
      const name = await radio.getAttribute('name');
      if (name && !seenGroups.has(name)) {
        seenGroups.add(name);
        await radio.click();
      }
    }

    // Use .first() — product pages with related products have multiple buttons
    const btn = this.page.locator(SEL.addToCartButton).first();
    await btn.scrollIntoViewIfNeeded();
    await btn.click();
    // Wait for success notification
    await this.waitForVisible(SEL.successNotification, 8_000);
  }

  // ── Assertions ────────────────────────────────────────────────

  async isAddToCartSuccessful() {
    return this.isDisplayed(SEL.successNotification);
  }

  async isProductDetailLoaded() {
    try {
      await this.page.locator(SEL.productDetailTitle).waitFor({ state: 'visible', timeout: 8_000 });
      return true;
    } catch {
      return false;
    }
  }
}

module.exports = { ProductPage };
