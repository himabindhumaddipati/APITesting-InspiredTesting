// pages/BasePage.js
const { expect } = require('@playwright/test');

class BasePage {
  constructor(page) {
    this.page = page;
  }

  // ─── Navigation ───────────────────────────────────────────────
  async navigateTo(url) {
    await this.page.goto(url, { waitUntil: 'domcontentloaded' });
  }

  async goto(path = '') {
    await this.page.goto(path, { waitUntil: 'domcontentloaded' });
  }

  getCurrentUrl() {
    return this.page.url();
  }

  // ─── Typing & Input ───────────────────────────────────────────
  async type(selector, value) {
    await this.page.locator(selector).fill(value);
  }

  async fill(selector, value) {
    await this.page.locator(selector).fill(value);
  }

  // ─── Clicking ─────────────────────────────────────────────────
  async click(selector, options = {}) {
    await this.page.locator(selector).click(options);
  }

  async jsClick(selector) {
    await this.page.locator(selector).evaluate((el) => el.click());
  }

  // ─── Select / Dropdowns ───────────────────────────────────────
  async selectByText(selector, text) {
    await this.page.locator(selector).selectOption({ label: text });
  }

  async selectByValue(selector, value) {
    await this.page.locator(selector).selectOption({ value });
  }

  async selectOption(selector, value) {
    await this.page.locator(selector).selectOption(value);
  }

  // ─── Waits ────────────────────────────────────────────────────
  async waitForVisible(selector, timeout = 10_000) {
    await this.page.locator(selector).waitFor({ state: 'visible', timeout });
  }

  async waitForClickable(selector, timeout = 10_000) {
    await this.page.locator(selector).waitFor({ state: 'visible', timeout });
    await expect(this.page.locator(selector)).toBeEnabled({ timeout });
  }

  async waitForSelector(selector, options = {}) {
    await this.page.waitForSelector(selector, { timeout: 10_000, ...options });
  }

  async waitForUrl(url, options = {}) {
    await this.page.waitForURL(url, { timeout: 15_000, ...options });
  }

  async waitForNetworkIdle() {
    await this.page.waitForLoadState('networkidle');
  }

  // ─── Getters ──────────────────────────────────────────────────
  async getText(selector) {
    return this.page.locator(selector).textContent();
  }

  async getValue(selector) {
    return this.page.locator(selector).inputValue();
  }

  async getInputValue(selector) {
    return this.page.locator(selector).inputValue();
  }

  // ─── Visibility ───────────────────────────────────────────────
  async isDisplayed(selector) {
    try {
      return await this.page.locator(selector).isVisible({ timeout: 3_000 });
    } catch {
      return false;
    }
  }

  async isVisible(selector) {
    return this.page.locator(selector).isVisible();
  }

  async isEnabled(selector) {
    return this.page.locator(selector).isEnabled();
  }

  // ─── Scroll ───────────────────────────────────────────────────
  async scrollTo(selector) {
    await this.page.locator(selector).scrollIntoViewIfNeeded();
  }

  async scrollIntoView(selector) {
    await this.page.locator(selector).scrollIntoViewIfNeeded();
  }

  // ─── Assertions ───────────────────────────────────────────────
  async assertVisible(selector) {
    await expect(this.page.locator(selector)).toBeVisible();
  }

  async assertText(selector, text) {
    await expect(this.page.locator(selector)).toHaveText(text);
  }

  async assertContainsText(selector, text) {
    await expect(this.page.locator(selector)).toContainText(text);
  }

  async assertUrl(pattern) {
    await expect(this.page).toHaveURL(pattern);
  }

  // ─── Screenshots ──────────────────────────────────────────────
  async takeScreenshot(name) {
    await this.page.screenshot({
      path: `reports/artifacts/${name}-${Date.now()}.png`,
      fullPage: true,
    });
  }
}

module.exports = { BasePage };
