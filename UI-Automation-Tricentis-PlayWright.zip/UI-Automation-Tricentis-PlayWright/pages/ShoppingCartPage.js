// pages/ShoppingCartPage.js
const { BasePage } = require('./BasePage');

// ── Selectors (replaces @FindBy annotations) ──────────────────
const SEL = {
  termsCheckbox:  '#termsofservice',
  checkoutButton: '#checkout',
  cartItems:      '.cart-item-row',
};

const BASE_URL = process.env.BASE_URL || 'https://demowebshop.tricentis.com';

/**
 * ShoppingCartPage
 * Converted from Java Selenium → Playwright JS
 */
class ShoppingCartPage extends BasePage {
  constructor(page) {
    super(page);
  }

  // ── Actions ───────────────────────────────────────────────────

  async open() {
    await this.navigateTo(`${BASE_URL}/cart`);
  }

  /** Remove all items from the cart — call in beforeEach to ensure a clean state. */
  async clearCart() {
    await this.navigateTo(`${BASE_URL}/cart`);
    // Tricentis remove buttons: input.remove-btn or td.remove-from-cart input
    const removeBtn = this.page.locator('input.remove-btn, td.remove-from-cart input[type="button"]');
    let count = await removeBtn.count();
    while (count > 0) {
      await removeBtn.first().click();
      await this.page.waitForLoadState('domcontentloaded');
      count = await removeBtn.count();
    }
  }

  async acceptTermsAndConditions() {
    await this.waitForClickable(SEL.termsCheckbox);
    const checked = await this.page.locator(SEL.termsCheckbox).isChecked();
    if (!checked) {
      // jsClick used — same as Java's jsClick for stubborn checkboxes
      await this.jsClick(SEL.termsCheckbox);
    }
  }

  /**
   * @param {string} [email]    - pass when Tricentis may redirect to login at checkout
   * @param {string} [password] - pass when Tricentis may redirect to login at checkout
   */
  async clickCheckout(email, password) {
    await this.click(SEL.checkoutButton);
    await this.page.waitForLoadState('domcontentloaded');
    // Tricentis redirects to /login even for logged-in users at checkout.
    // Re-authenticate using the credentials passed from the test.
    if (this.page.url().includes('/login') && email && password) {
      await this.page.locator('#Email').fill(email);
      await this.page.locator('#Password').fill(password);
      await this.page.locator('input.login-button').click();
      await this.page.waitForLoadState('networkidle');
    }
  }

  // ── Assertions ────────────────────────────────────────────────

  async getCartItemCount() {
    return this.page.locator(SEL.cartItems).count();
  }

  async isCartPageDisplayed() {
    return this.getCurrentUrl().includes('/cart');
  }
}

module.exports = { ShoppingCartPage };
