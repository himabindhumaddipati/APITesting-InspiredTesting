// fixtures/index.js
const { test: base, expect } = require('@playwright/test');
const { LoginPage }        = require('../pages/LoginPage');
const { HomePage }         = require('../pages/HomePage');
const { ProductPage }      = require('../pages/ProductPage');
const { ShoppingCartPage } = require('../pages/ShoppingCartPage');
const { CheckoutPage }     = require('../pages/CheckoutPage');

/**
 * Custom fixtures — ALL page objects registered here.
 * Tests just destructure what they need — no manual imports.
 */
const test = base.extend({

  // ─── Tricentis Page Objects ────────────────────────────────
  loginPage:        async ({ page }, use) => await use(new LoginPage(page)),
  homePage:         async ({ page }, use) => await use(new HomePage(page)),
  productPage:      async ({ page }, use) => await use(new ProductPage(page)),
  shoppingCartPage: async ({ page }, use) => await use(new ShoppingCartPage(page)),
  checkoutPage:     async ({ page }, use) => await use(new CheckoutPage(page)),

  // ─── API Request context ────────────────────────────────────
  apiContext: async ({ playwright }, use) => {
    const context = await playwright.request.newContext({
      baseURL: process.env.API_BASE_URL || 'https://api.example.com',
      extraHTTPHeaders: {
        Authorization: `Bearer ${process.env.API_TOKEN || ''}`,
        'Content-Type': 'application/json',
      },
    });
    await use(context);
    await context.dispose();
  },

  // ─── Test data fixture ──────────────────────────────────────
  testData: async ({}, use) => {
    const data = require('./testData.json');
    await use(data);
  },
});

module.exports = { test, expect };
